<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Yatras - IndiYatri</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .yatra-card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .yatra-card:hover {
      transform: scale(1.05);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
    }

    .yatra-card img {
      height: 220px;
      object-fit: cover;
    }

    .card-body h5 {
      font-weight: bold;
    }

    .search-btn {
      background: linear-gradient(135deg, #1e90ff, #00bfff);
      color: #fff;
      border: none;
      padding: 8px 20px;
      border-radius: 30px;
      font-weight: 500;
      transition: all 0.3s ease;
    }

    .search-btn:hover {
      background: linear-gradient(135deg, #005cbf, #0096c7);
      transform: scale(1.05);
      box-shadow: 0 8px 15px rgba(0, 123, 255, 0.2);
    }

    .row.g-4>[class*="col-"] {
      margin-bottom: 30px;
    }

    .crossed-flag {
      font-weight: bold;
      font-size: 28px;
      background: linear-gradient(45deg, #ff9933 0%, #ffffff 50%, #138808 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: inline-block;
    }
  </style>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand crossed-flag" href="#">IndiYatri</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse"
        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="index.php">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact Us</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>


  <!-- Yatra Section -->
  <section class="my-5 py-5 px-3 px-md-5">
    <div class="py-3 text-center">
      <h2>Our Spiritual Yatras</h2>
      <p class="text-muted mb-4">Reconnect with India's spiritual soul through our guided yatras.</p>
      <input id="yatraSearch" class="form-control mb-5 mx-auto d-block w-50" type="text" placeholder="Search for a Yatra..." />
    </div>





    <div class="container">
      <div id="yatraCards" class="row g-4">
        <!-- Row 1 -->
        <div class="col-md-4">
          <div class="card yatra-card" onclick="window.open('https://www.google.com/search?q=Kedarnath+Yatra', '_blank')" style="cursor: pointer;">
            <img src="image/kedarnath.jpg" class="card-img-top" alt="Kedarnath">
            <div class="card-body">
              <h5 class="card-title">Kedarnath Yatra</h5>
              <p class="card-text">Trek through the Himalayas to reach one of the holiest Shiva temples.</p>
              <p><a href="https://www.google.com/maps?q=Kedarnath+Temple" target="_blank" class="text-primary">📍Location</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card yatra-card" onclick="window.open('https://www.google.com/search?q=Varanasi+Pilgrimage', '_blank')" style="cursor: pointer;">
            <img src="image/varanasi.jpg" class="card-img-top" alt="Varanasi">
            <div class="card-body">
              <h5 class="card-title">Varanasi Pilgrimage</h5>
              <p class="card-text">Attend the Ganga Aarti and witness spiritual rituals on sacred ghats.</p>
              <p><a href="https://www.google.com/maps?q=Varanasi+Ghats" target="_blank" class="text-primary">📍Location</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card yatra-card" onclick="window.open('https://www.google.com/search?q=Amarnath+Yatra', '_blank')" style="cursor: pointer;">
            <img src="image/amarnath.jpg" class="card-img-top" alt="Amarnath">
            <div class="card-body">
              <h5 class="card-title">Amarnath Yatra</h5>
              <p class="card-text">A challenging spiritual journey to the naturally formed ice Shiva linga.</p>
              <p><a href="https://www.google.com/maps?q=Amarnath+Cave+Temple" target="_blank" class="text-primary">📍Location</a></p>
            </div>
          </div>
        </div>

        <!-- Row 2 -->
        <div class="col-md-4">
          <div class="card yatra-card" onclick="window.open('https://www.google.com/search?q=Rishikesh+Spiritual+Tour', '_blank')" style="cursor: pointer;">
            <img src="image/rishikesh.jpg" class="card-img-top" alt="Rishikesh">
            <div class="card-body">
              <h5 class="card-title">Rishikesh</h5>
              <p class="card-text">Attend the Ganga Aarti and witness spiritual rituals on sacred ghats.</p>
              <p><a href="https://www.google.com/maps?q=Rishikesh" target="_blank" class="text-primary">📍Location</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card yatra-card" onclick="window.open('https://www.google.com/search?q=Jagannath+Puri+Yatra', '_blank')" style="cursor: pointer;">
            <img src="image/puri.jpg" class="card-img-top" alt="Jagannath Puri">
            <div class="card-body">
              <h5 class="card-title">Jagannath Puri</h5>
              <p class="card-text">Attend the Ganga Aarti and witness spiritual rituals on sacred ghats.</p>
              <p><a href="https://www.google.com/maps?q=Jagannath+Puri+Temple" target="_blank" class="text-primary">📍Location</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card yatra-card" onclick="window.open('https://www.google.com/search?q=Tirupati+Balaji+Temple', '_blank')" style="cursor: pointer;">
            <img src="image/tirupati.jpg" class="card-img-top" alt="Tirupati Balaji">
            <div class="card-body">
              <h5 class="card-title">Tirupati Balaji</h5>
              <p class="card-text">Attend the Ganga Aarti and witness spiritual rituals on sacred ghats.</p>
              <p><a href="https://www.google.com/maps?q=Tirupati+Balaji+Temple" target="_blank" class="text-primary">📍Location</a></p>
            </div>
          </div>
        </div>
      </div>
    </div>


  </section>

  </section>

  <!-- Footer -->
  <footer style="background-color: #0f172a; color: #f8fafc; padding: 40px 20px; font-family: 'Segoe UI', sans-serif;">
    <div style="max-width: 1000px; margin: auto; text-align: center;">
      <p style="margin-bottom: 25px; color: #94a3b8;">I write code, design interfaces, seamless user experiences! Let's connect.</p>
      <div style="margin-bottom: 25px;">
        <a href="/about.php" style="color: #38bdf8; margin: 0 12px; text-decoration: none;">About</a>
        <a href="/projects.html" style="color: #38bdf8; margin: 0 12px; text-decoration: none;">Projects</a>
        <a href="/contact.php" style="color: #38bdf8; margin: 0 12px; text-decoration: none;">Contact</a>
        <a href="/coffee.html" style="color: #38bdf8; margin: 0 12px; text-decoration: none;">Buy me a ☕</a>
      </div>
      <div style="margin-bottom: 20px;">
        <a href="https://github.com/Varunsinh" target="_blank" style="margin: 0 10px; color: #f8fafc;">GitHub</a>
        <a href="https://www.linkedin.com/in/varunsinh-yadav-22a894213" target="_blank" style="margin: 0 10px; color: #f8fafc;">LinkedIn</a>
        <a href="mailto:varunsinhyadav50@gmail.com" style="margin: 0 10px; color: #f8fafc;">Email</a>
      </div>
      <p style="font-size: 14px; color: #64748b;">
        &copy; 2025 IndiYatri — Coded with 💻, styled with 🎨.
      </p>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Live Search Filter -->
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const searchInput = document.getElementById("yatraSearch");
      const cardContainer = document.getElementById("yatraCards");
      const cards = document.querySelectorAll(".yatra-card");

      searchInput.addEventListener("input", function() {
        const query = this.value.toLowerCase().trim();
        let matchCount = 0;

        cards.forEach(card => {
          const title = card.querySelector(".card-title").textContent.toLowerCase();
          const text = card.querySelector(".card-text").textContent.toLowerCase();
          const match = title.includes(query) || text.includes(query);

          card.parentElement.style.display = match || query === "" ? "block" : "none";
          if (match) matchCount++;
        });

        // Remove any previous centering
        cardContainer.classList.remove("justify-content-center", "row");

        if (matchCount === 1) {
          cardContainer.classList.add("d-flex", "justify-content-center", "flex-wrap");
        } else {
          cardContainer.className = "row g-4";
        }
      });
    });
  </script>


</body>

</html>