<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contact Us - IndiYatri</title>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .contact-section {
      padding: 60px 0;
      background-color: #f5f5f5;
    }

    .contact-box {
      background: #ffffff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .form-control:focus {
      box-shadow: none;
      border-color: #28a745;
    }

    footer a:hover {
      text-decoration: underline;
    }
  </style>
</head>

<body>

  <!-- NAVBAR -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">IndiYatri</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
        <li class="nav-item active"><a class="nav-link" href="userinfo.php">Contact Us</a></li>
      </ul>
    </div>
  </nav>

  <!-- CONTACT FORM -->
  <section class="contact-section">
    <div class="container">
      <div class="text-center mb-4">
        <h2>Contact Us</h2>
        <p class="text-muted">We’d love to hear from you. Send us a message below.</p>
      </div>
      <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="contact-box">
            <form action="userinfo.php" method="POST">
              <div class="form-group">
                <label for="user">Full Name</label>
                <input type="text" class="form-control" id="user" name="user" required>
              </div>
              <div class="form-group">
                <label for="email">Email address</label>
                <input type="email" class="form-control" id="email" name="email" required>
              </div>
              <div class="form-group">
                <label for="mobile">Phone Number</label>
                <input type="tel" class="form-control" id="mobile" name="mobile">
              </div>
              <div class="form-group">
                <label for="comment">Your Message</label>
                <textarea class="form-control" id="comment" name="comment" rows="4" required></textarea>
              </div>
              <button type="submit" class="btn btn-success btn-block">Send Message</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="bg-dark text-light py-4 text-center">
    <p>Made by IndiYatri — Exploring India Together 🌏</p>
    <div>
      <a href="about.php" class="text-info mx-2">About</a>
      <a href="#" class="text-info mx-2">Projects</a>
      <a href="userinfo.php" class="text-info mx-2">Contact</a>
      <a href="#" class="text-info mx-2">Buy me a ☕</a>
    </div>
    <div class="mt-2">
      <a href="https://github.com/Varunsinh" target="_blank" class="text-light mx-2">GitHub</a>
      <a href="https://www.linkedin.com/in/varunsinh-yadav-22a894213" target="_blank" class="text-light mx-2">LinkedIn</a>
      <a href="mailto:varunsinhyadav50@gmail.com" class="text-light mx-2">Email</a>
    </div>
    <p class="text-muted small mt-2">&copy; 2025 IndiYatri. All Rights Reserved.</p>
  </footer>

  <!-- JS Scripts -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>