<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
       body{
            background-image: url('image/25.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            height: 80vh;
            margin: 0;
            background-color:rgb(80, 80, 72);
            font-family: mall-caps slashed-zero;
       }

       .signup-box{
            background:rgba(223, 223, 223, 0.6) ;
            height: 315px;
            width: 400px;
            margin: 150px auto;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 20px #aaa;
       }

       input[type="text"], input[type="password"]
       {
            width: 95%;
            padding: 8px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
       }

       input[type="submit"]
       {
            width: 90%;
            padding: 10px;
            background-color:#17a589;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
       }

       .success {
            color: green;
        }
        .error {
            color: red;
        }

    </style>
</head>
<body>
    <div class="signup-box">
        <h1 style="text-align:center;font-size:xx-large">Signup</h1>
        <form method="post" action="">

            
            <label>Username:</label>
            
            <input type="text" name="username" required>
            

            <label>Password:</label>
            
            <input type="password" name="password" required>
            

            <div style="text-align: center;">
            <input type="submit" name="signup" value="Signup">
            </div>
        </form>

        <?php
        if(isset($_POST['signup']))
        {
            $username=trim($_POST['username']);
            $password=trim($_POST['password']);

            $file=fopen("users.txt","a");
            fwrite($file,$username .",".$password."\n");
            fclose($file);

             echo "<p class='success'>Signup successful! <a href='login.php'>Click to login</a></p>";
        }
        ?>
    </div>
</body>
</html>