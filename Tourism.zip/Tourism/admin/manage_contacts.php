<?php


$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "userinfo";


$con = mysqli_connect($servername, $username, $password, $dbname);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    mysqli_query($con, "DELETE FROM contact_details WHERE id=$id");
    header("Location: manage_contacts.php");
    exit;
}


$sql = "SELECT id, name, email, mobile, comment FROM contact_details ORDER BY id ASC";
$result = mysqli_query($con, $sql);
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tourism Admin - Manage Contact Forms</title>
    <link rel="stylesheet" href="css/style.css">

    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background-color: #f2f2f2; }
        .btn { padding: 5px 10px; margin-right: 5px; cursor: pointer; border: none; border-radius: 4px; text-decoration: none; }
        .btn.primary { background-color: #007bff; color: #fff; }
        .btn.secondary { background-color: #6c757d; color: #fff; }
        .btn.warn { background-color: #dc3545; color: #fff; }
    </style>
</head>

<body>
    <div class="app">

        <?php include_once 'header.php'; ?>

        <div class="main">
            <header class="appbar">
                <h2>Manage Contact Forms</h2>
            </header>

            <main class="content">
                <div class="card">
                    <h3>User Messages</h3>

                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Message</th>
                               
                                <th>Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php if (mysqli_num_rows($result) > 0): ?>
                                <?php while($row = mysqli_fetch_assoc($result)): ?>
                                    <tr>
                                        <td><?= $row['id']; ?></td>
                                        <td><?= htmlspecialchars($row['name']); ?></td>
                                        <td><?= htmlspecialchars($row['email']); ?></td>
                                        <td><?= htmlspecialchars($row['mobile']); ?></td>
                                        <td><?= htmlspecialchars($row['comment']); ?></td>
                                      

                                        <td>
                                            <!-- MARK READ -->
                                            <form method="post" action="manage_contacts.php" style="display:inline;">
                                                <input type="hidden" name="id" value="<?= $row['id']; ?>">
                                                <button type="submit" name="mark_read" class="btn secondary">Mark Read</button>
                                            </form>

                                            <!-- REPLY -->
                                            <a href="mailto:<?= htmlspecialchars($row['email']); ?>" class="btn primary">Reply</a>

                                            <!-- DELETE -->
                                            <a href="manage_contacts.php?delete_id=<?= $row['id']; ?>"
                                               class="btn warn"
                                               onclick="return confirm('Are you sure you want to delete this message?');">
                                               Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>

                            <?php else: ?>
                                <tr><td colspan="7">No messages found.</td></tr>
                            <?php endif; ?>
                        </tbody>

                    </table>
                </div>
            </main>

        </div>
    </div>

</body>
</html>

<?php mysqli_close($con); ?>
