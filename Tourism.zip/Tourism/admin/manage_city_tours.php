<?php
// admin/manage_city_tours.php
require "../config.php";

// Check DB connection
if (!isset($conn) || !$conn) {
    die("Database connection not found. Check config.php (it must set \$conn = mysqli_connect(...)).");
}

// Add City Tour
if (isset($_POST['action']) && $_POST['action'] === "add") {
    $city_id = "C-" . (5000 + rand(100, 999));
    $name = mysqli_real_escape_string($conn, $_POST['name'] ?? '');
    $city = mysqli_real_escape_string($conn, $_POST['city'] ?? '');
    $desc = mysqli_real_escape_string($conn, $_POST['desc'] ?? '');

    // Handle image upload
    $imageName = "";
    if (!empty($_FILES['image']['name'])) {
        $original = basename($_FILES['image']['name']);
        $ext = pathinfo($original, PATHINFO_EXTENSION);
        $imageName = time() . "_" . preg_replace('/[^A-Za-z0-9_\-]/', '', pathinfo($original, PATHINFO_FILENAME)) . ($ext ? ".".$ext : "");

        $targetDir = __DIR__ . "/../uploads/cities/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }
        $targetPath = $targetDir . $imageName;
        move_uploaded_file($_FILES['image']['tmp_name'], $targetPath);
    }

    $sql = "INSERT INTO cities (city_id, name, city, description, image) 
            VALUES ('$city_id', '$name', '$city', '$desc', '$imageName')";
    mysqli_query($conn, $sql);

    header("Location: manage_city_tours.php");
    exit;
}

// Delete City Tour
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    // Delete image file
    $q = mysqli_query($conn, "SELECT image FROM cities WHERE id = $id LIMIT 1");
    if ($q && mysqli_num_rows($q) > 0) {
        $row = mysqli_fetch_assoc($q);
        if (!empty($row['image'])) {
            $filePath = __DIR__ . "/../uploads/cities/" . $row['image'];
            if (file_exists($filePath)) unlink($filePath);
        }
    }

    mysqli_query($conn, "DELETE FROM cities WHERE id = $id");
    header("Location: manage_city_tours.php");
    exit;
}

// Fetch all City Tours
$citiesRes = mysqli_query($conn, "SELECT * FROM cities ORDER BY id DESC");
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Tourism Admin - Manage City Tours</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app">
    <?php include_once 'header.php'; ?>

    <div class="main">
        <header class="appbar">
            <h2>Manage City Tours</h2>
            <button class="btn primary" onclick="showAddForm()">+ Add City Tour</button>
        </header>

        <main class="content">
            <div class="card" id="addForm" style="display:none;">
                <h3>Add New City Tour</h3>
                <form method="POST" enctype="multipart/form-data" class="form-inline">
                    <input type="hidden" name="action" value="add">
                    <input type="text" name="name" placeholder="City Tour Name" required>
                    <input type="text" name="city" placeholder="City" required>
                    <textarea name="desc" placeholder="Description"></textarea>
                    <input type="file" name="image" accept="image/*">
                    <button class="btn primary" type="submit">Save</button>
                </form>
            </div>

            <div class="card">
                <h3 style="margin:0 0 10px">City Tours List</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>City</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($city = mysqli_fetch_assoc($citiesRes)) : ?>
                        <tr>
                            <td>
                                <?php
                                $imgFile = $city['image'] ?? '';
                                $imgPath = "../uploads/cities/" . $imgFile;
                                if (!empty($imgFile) && file_exists(__DIR__ . "/../uploads/cities/" . $imgFile)) : ?>
                                    <img src="<?= htmlspecialchars($imgPath) ?>" class="city-img" alt="<?= htmlspecialchars($city['name']) ?>">
                                <?php else : ?>
                                    <img src="https://via.placeholder.com/100x65?text=No+Image" class="city-img" alt="No image">
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($city['name']) ?></td>
                            <td><?= htmlspecialchars($city['city']) ?></td>
                            <td><?= htmlspecialchars($city['description']) ?></td>
                            <td class="actions-cell">
                                <a href="manage_city_tours.php?delete=<?= intval($city['id']) ?>" class="btn warn" onclick="return confirm('Delete this City Tour?')">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>

<script>
function showAddForm() {
    document.getElementById('addForm').style.display = 'block';
}
</script>
</body>
</html>
