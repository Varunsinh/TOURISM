<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Tourism Admin - Users</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="app">
    <?php include_once 'header.php'; ?>

    <div class="main">
      <header class="appbar">
        <h2> Manage Users</h2>
        <button class="btn primary" onclick="addUser()">+ Add User</button>
      </header>

      <main class="content">
        <div class="card">
          <h3 style="margin:0 0 10px">User List</h3>
          <table>
            <thead>
              <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="usersTableBody"></tbody>
          </table>
        </div>
      </main>
    </div>
  </div>

  <script>
    const users = [{
        id: 'U-1001',
        name: 'Amit Shah',
        email: 'amit@example.com',
        role: 'Traveler',
        status: 'Active'
      },
      {
        id: 'U-1002',
        name: 'Priya Patel',
        email: 'priya@example.com',
        role: 'Traveler',
        status: 'Inactive'
      },
      {
        id: 'U-1003',
        name: 'Rahul Mehta',
        email: 'rahul@example.com',
        role: 'Admin',
        status: 'Active'
      }
    ];

    function renderUsers() {
      const tbody = document.getElementById('usersTableBody');
      tbody.innerHTML = '';
      users.forEach(u => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${u.id}</td>
          <td>${u.name}</td>
          <td>${u.email}</td>
          <td>${u.role}</td>
          <td>${u.status}</td>
          <td class="actions-cell">
            <button class="btn primary" onclick="editUser('${u.id}')">Edit</button>
            <button class="btn warn" onclick="deleteUser('${u.id}')">Delete</button>
          </td>`;
        tbody.appendChild(tr);
      });
    }

    function addUser() {
      const id = 'U-' + (1000 + users.length + 1);
      users.push({
        id,
        name: 'New User ' + (users.length + 1),
        email: 'new@example.com',
        role: 'Traveler',
        status: 'Active'
      });
      renderUsers();
      alert('User ' + id + ' added (sample)');
    }

    function editUser(id) {
      const u = users.find(x => x.id === id);
      if (!u) return;
      const newName = prompt('Edit name:', u.name);
      if (newName !== null) {
        u.name = newName;
        renderUsers();
      }
    }

    function deleteUser(id) {
      if (confirm('Delete user ' + id + '?')) {
        const idx = users.findIndex(x => x.id === id);
        if (idx > -1) {
          users.splice(idx, 1);
          renderUsers();
        }
      }
    }

    renderUsers();
  </script>
</body>

</html>