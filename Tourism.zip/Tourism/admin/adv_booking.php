<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "userinfo");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    $conn->query("DELETE FROM adv_bookings WHERE id=$id");
    header("Location: adv_booking.php");
    exit;
}

// Fetch all adventure bookings
$result = $conn->query("SELECT * FROM adv_bookings ORDER BY created_at ASC");
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin - Adventure Bookings</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="app">
    <?php include_once 'header.php'; ?>
    <div class="main">
      <header class="appbar">
        <h2>Manage Adventure Bookings</h2>
      </header>

      <main class="content">
        <div class="card">
          <h3 style="margin:0 0 10px">Booking List</h3>
          <table border="1" cellpadding="10" cellspacing="0">
            <thead>
              <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Trip Name</th>
                <th>Travel Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php while($b = $result->fetch_assoc()): ?>
              <tr>
                <td><?= htmlspecialchars($b['id']) ?></td>
                <td><?= htmlspecialchars($b['full_name']) ?></td>
                <td><?= htmlspecialchars($b['email']) ?></td>
                <td><?= htmlspecialchars($b['contact']) ?></td>
                <td><?= htmlspecialchars($b['description']) ?></td>
                <td><?= htmlspecialchars($b['travel_date']) ?></td>
                <td class="button">
                  <a href="adv_booking.php?delete_id=<?= $b['id'] ?>" class="btn btn-danger btn-sm"
                     onclick="return confirm('Are you sure you want to delete this booking?');">Delete</a>
                  <!-- Optional Edit button -->
                  <!-- <a href="edit_adv_booking.php?id=<?= $b['id'] ?>" class="btn btn-primary btn-sm">Edit</a> -->
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </main>
    </div>
  </div>
</body>
</html>

<?php $conn->close(); ?>
