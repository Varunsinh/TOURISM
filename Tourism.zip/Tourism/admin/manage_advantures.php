<?php
// admin/manage_adventures.php
require "../config.php";

// Check DB connection
if (!isset($conn) || !$conn) {
    die("Database connection not found. Check config.php (it must set \$conn = mysqli_connect(...)).");
}

// Add Adventure
if (isset($_POST['action']) && $_POST['action'] === "add") {
    $adv_id = "A-" . (4000 + rand(100, 999));
    $name = mysqli_real_escape_string($conn, $_POST['name'] ?? '');
    $location = mysqli_real_escape_string($conn, $_POST['location'] ?? '');
    $desc = mysqli_real_escape_string($conn, $_POST['desc'] ?? '');

    // Handle image upload
    $imageName = "";
    if (!empty($_FILES['image']['name'])) {
        $original = basename($_FILES['image']['name']);
        $ext = pathinfo($original, PATHINFO_EXTENSION);
        $imageName = time() . "_" . preg_replace('/[^A-Za-z0-9_\-]/', '', pathinfo($original, PATHINFO_FILENAME)) . ($ext ? ".".$ext : "");

        $targetDir = __DIR__ . "/../uploads/adventures/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }
        $targetPath = $targetDir . $imageName;
        move_uploaded_file($_FILES['image']['tmp_name'], $targetPath);
    }

    $sql = "INSERT INTO adventures (adv_id, name, location, description, image) 
            VALUES ('$adv_id', '$name', '$location', '$desc', '$imageName')";
    mysqli_query($conn, $sql);

    header("Location: manage_advantures.php");
    exit;
}

// Delete Adventure
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    // Delete image file
    $q = mysqli_query($conn, "SELECT image FROM adventures WHERE id = $id LIMIT 1");
    if ($q && mysqli_num_rows($q) > 0) {
        $row = mysqli_fetch_assoc($q);
        if (!empty($row['image'])) {
            $filePath = __DIR__ . "/../uploads/adventures/" . $row['image'];
            if (file_exists($filePath)) unlink($filePath);
        }
    }

    mysqli_query($conn, "DELETE FROM adventures WHERE id = $id");
    header("Location: manage_advantures.php");
    exit;
}

// Fetch Adventures
$adventuresRes = mysqli_query($conn, "SELECT * FROM adventures ORDER BY id DESC");
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Tourism Admin - Manage Adventures</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app">
    <?php include_once 'header.php'; ?>

    <div class="main">
        <header class="appbar">
            <h2>Manage Adventures</h2>
            <button class="btn primary" onclick="showAddForm()">+ Add Adventure</button>
        </header>

        <main class="content">
            <div class="card" id="addForm" style="display:none;">
                <h3>Add New Adventure</h3>
                <form method="POST" enctype="multipart/form-data" class="form-inline">
                    <input type="hidden" name="action" value="add">
                    <input type="text" name="name" placeholder="Adventure Name" required>
                    <input type="text" name="location" placeholder="Location" required>
                    <textarea name="desc" placeholder="Description"></textarea>
                    <input type="file" name="image" accept="image/*">
                    <button class="btn primary" type="submit">Save</button>
                </form>
            </div>

            <div class="card">
                <h3 style="margin:0 0 10px">Adventure List</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Location</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($adv = mysqli_fetch_assoc($adventuresRes)) : ?>
                        <tr>
                            <td>
                                <?php
                                $imgFile = $adv['image'] ?? '';
                                $imgPath = "../uploads/adventures/" . $imgFile;
                                if (!empty($imgFile) && file_exists(__DIR__ . "/../uploads/adventures/" . $imgFile)) : ?>
                                    <img src="<?= htmlspecialchars($imgPath) ?>" class="adventure-img" alt="<?= htmlspecialchars($adv['name']) ?>">
                                <?php else : ?>
                                    <img src="https://via.placeholder.com/100x65?text=No+Image" class="adventure-img" alt="No image">
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($adv['name']) ?></td>
                            <td><?= htmlspecialchars($adv['location']) ?></td>
                            <td><?= htmlspecialchars($adv['description']) ?></td>
                            <td class="actions-cell">
                                <a href="manage_advantures.php?delete=<?= intval($adv['id']) ?>" class="btn warn" onclick="return confirm('Delete this Adventure?')">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>

<script>
function showAddForm() {
    document.getElementById('addForm').style.display = 'block';
}
</script>
</body>
</html>
