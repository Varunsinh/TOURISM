<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>About Us - IndiYatri</title>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .about-section {
      padding: 60px 0;
      background-color: #f9f9f9;
    }

    .about-image {
      width: 100%;
      height: auto;
      border-radius: 10px;
    }

    .team-member {
      text-align: center;
      padding: 15px;
    }

    .team-member img {
      width: 180px;
      height: 180px;
      object-fit: cover;
      border-radius: 50%;
      margin-bottom: 10px;
      border: 3px solid #17a2b8;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    footer a:hover {
      text-decoration: underline;
    }
  </style>
</head>

<body>

  <!-- NAVBAR -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">IndiYatri</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        
        
        
      </ul>
    </div>
  </nav>

  <!-- ABOUT US SECTION -->
  <section class="about-section">
    <div class="container">
      <div class="text-center mb-5">
        <h2>About IndiYatri</h2>
        <p class="lead">Discover India with trust, comfort, and authenticity.</p>
      </div>
      <div class="row align-items-center">
        <div class="col-md-6">
          <img src="image/09.jpg" alt="IndiYatri Team" class="about-image">
        </div>
        <div class="col-md-6">
          <h3>Who We Are</h3>
          <p>IndiYatri is your travel companion for discovering the rich culture, heritage, and natural beauty of India. Our mission is to make every journey memorable by offering personalized experiences across the country's most iconic and hidden gems.</p>
          <p>Whether you're looking for spiritual yatras, adventure trails, cultural tours, or simply want to explore offbeat destinations, IndiYatri ensures a smooth, informative, and safe journey.</p>
          <a href="contact.php" class="btn btn-success mt-3">Contact Us</a>
        </div>
      </div>
    </div>
  </section>

  <!-- TEAM SECTION -->
  <section class="bg-light py-5">
    <div class="container">
      <div class="text-center mb-4">
        <h3>Meet Our Team</h3>
        <p class="text-muted">Passionate travelers behind IndiYatri</p>
      </div>
      <div class="row">
        <div class="col-md-4 team-member">
          <img src="image/winter.jpg" alt="Varunsinh Yadav">
          <h5>Varunsinh Yadav</h5>
          <p>Founder & Lead Explorer</p>
        </div>
        <div class="col-md-4 team-member">
          <img src="image/ronitbhai.jpg" alt="Ronit Kachadiya">
          <h5>Ronit Kachadiya</h5>
          <p>Travel Guide Coordinator</p>
        </div>
        <div class="col-md-4 team-member">
          <img src="image/jaiminbhai.jpg" alt="Jaiminkumar Rajput">
          <h5>Jaiminkumar Rajput</h5>
          <p>Digital Content Creator</p>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="bg-dark text-light py-4 text-center">
    <p>Made by IndiYatri — Exploring India Together 🌏</p>
    <div>
      <a href="about.php" class="text-info mx-2">About</a>
      <a href="#" class="text-info mx-2">Projects</a>
      <a href="userinfo.php" class="text-info mx-2">Contact</a>
      <a href="#" class="text-info mx-2">Buy me a ☕</a>
    </div>
    <div class="mt-2">
      <a href="https://github.com/Varunsinh" target="_blank" class="text-light mx-2">GitHub</a>
      <a href="https://www.linkedin.com/in/varunsinh-yadav-22a894213" target="_blank" class="text-light mx-2">LinkedIn</a>
      <a href="mailto:varunsinhyadav50@gmail.com" class="text-light mx-2">Email</a>
    </div>
    <p class="text-muted small mt-2">&copy; 2025 IndiYatri. All Rights Reserved.</p>
  </footer>

  <!-- JS Scripts -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>