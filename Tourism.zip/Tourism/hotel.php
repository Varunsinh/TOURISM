<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Hotel Booking - IndiYatri</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .hotel-card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .hotel-card:hover {
      transform: scale(1.05);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
    }

    .hotel-card img {
      height: 220px;
      object-fit: cover;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
    }

    .price {
      font-weight: bold;
      color: #28a745;
    }

    .book-btn {
      background: linear-gradient(135deg, #ff5722, #ff8a50);
      color: #fff;
      border: none;
      padding: 8px 20px;
      border-radius: 30px;
      font-weight: 500;
      transition: all 0.3s ease;
    }

    .book-btn:hover {
      background: linear-gradient(135deg, #e64a19, #ff7043);
      transform: scale(1.05);
      box-shadow: 0 8px 15px rgba(255, 87, 34, 0.2);
    }

    .row.g-4>[class*="col-"] {
      margin-bottom: 30px;
    }

    .crossed-flag {
      font-weight: bold;
      font-size: 28px;
      background: linear-gradient(45deg, #ff9933 0%, #ffffff 50%, #138808 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: inline-block;
    }
  </style>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand crossed-flag" href="#">IndiYatri</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse"
        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php">Services</a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact Us</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Hotel Booking Section -->
  <section class="my-5 py-5 px-3 px-md-5">
    <div class="py-3 text-center">
      <h2>Book Your Stay</h2>
      <p class="text-muted mb-4">Choose from premium and budget hotels across India.</p>
      <input id="hotelSearch" class="form-control mb-5 mx-auto d-block w-50" type="text" placeholder="Search hotels..." />
    </div>

    <div class="container">
      <div id="hotelCards" class="row g-4">
        <!-- Row 1 -->
        <div class="col-md-4">
          <div class="card hotel-card">
            <img src="image/taj.jpg" alt="Taj Palace">
            <div class="card-body">
              <h5 class="card-title">Taj Palace, Mumbai</h5>
              <p class="card-text">Luxury 5-star hotel with ocean views and world-class service.</p>
              <p class="price">₹15,000 / night</p>
              <button class="book-btn" onclick="alert('Booking for Taj Palace coming soon!')">Book Now</button>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card hotel-card">
            <img src="image/hotel_oberai.jpg" alt="Oberoi Udaivilas">
            <div class="card-body">
              <h5 class="card-title">Oberoi Udaivilas, Udaipur</h5>
              <p class="card-text">Palatial luxury with lakeside views and royal hospitality.</p>
              <p class="price">₹25,000 / night</p>
              <button class="book-btn" onclick="alert('Booking for Oberoi Udaivilas coming soon!')">Book Now</button>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card hotel-card">
            <img src="image/hotel_goa.jpg" alt="Goa Beach Resort">
            <div class="card-body">
              <h5 class="card-title">Goa Beach Resort</h5>
              <p class="card-text">Beachfront resort with pool and private beach access.</p>
              <p class="price">₹7,500 / night</p>
              <button class="book-btn" onclick="alert('Booking for Goa Beach Resort coming soon!')">Book Now</button>
            </div>
          </div>
        </div>

        <!-- Row 2 -->
        <div class="col-md-4">
          <div class="card hotel-card">
            <img src="image/hotel_kerala.jpg" alt="Kerala Houseboat Stay">
            <div class="card-body">
              <h5 class="card-title">Kerala Hotel Stay</h5>
              <p class="card-text">Stay in traditional houseboats along Kerala backwaters.</p>
              <p class="price">₹5,000 / night</p>
              <button class="book-btn" onclick="alert('Booking for Kerala Houseboat coming soon!')">Book Now</button>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card hotel-card">
            <img src="image/hotel_delhi.jpg" alt="Delhi City Hotel">
            <div class="card-body">
              <h5 class="card-title">Delhi City Hotel</h5>
              <p class="card-text">Comfortable budget-friendly stay in the heart of Delhi.</p>
              <p class="price">₹3,000 / night</p>
              <button class="book-btn" onclick="alert('Booking for Delhi City Hotel coming soon!')">Book Now</button>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card hotel-card">
            <img src="image/hotel_manali.jpg" alt="Manali Mountain View">
            <div class="card-body">
              <h5 class="card-title">Manali Mountain View</h5>
              <p class="card-text">Cozy mountain resort with snow-capped views.</p>
              <p class="price">₹4,500 / night</p>
              <button class="book-btn" onclick="alert('Booking for Manali Mountain View coming soon!')">Book Now</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer style="background-color: #0f172a; color: #f8fafc; padding: 40px 20px;">
    <div style="max-width: 1000px; margin: auto; text-align: center;">
      <p style="margin-bottom: 25px; color: #94a3b8;">Book your perfect stay across India with IndiYatri.</p>
      <div style="margin-bottom: 25px;">
        <a href="/about.php" style="color: #38bdf8; margin: 0 12px;">About</a>
        <a href="/projects.html" style="color: #38bdf8; margin: 0 12px;">Projects</a>
        <a href="/contact.php" style="color: #38bdf8; margin: 0 12px;">Contact</a>
        <a href="/coffee.html" style="color: #38bdf8; margin: 0 12px;">Buy me a ☕</a>
      </div>
      <div style="margin-bottom: 20px;">
        <a href="https://github.com/Varunsinh" target="_blank" style="margin: 0 10px; color: #f8fafc;">GitHub</a>
        <a href="https://www.linkedin.com/in/varunsinh-yadav-22a894213" target="_blank" style="margin: 0 10px; color: #f8fafc;">LinkedIn</a>
        <a href="mailto:varunsinhyadav50@gmail.com" style="margin: 0 10px; color: #f8fafc;">Email</a>
      </div>
      <p style="font-size: 14px; color: #64748b;">
        &copy; 2025 IndiYatri — Hotel Booking Services 🏨
      </p>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Live Search -->
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const searchInput = document.getElementById("hotelSearch");
      const cardContainer = document.getElementById("hotelCards");
      const cards = document.querySelectorAll(".hotel-card");

      searchInput.addEventListener("input", function() {
        const query = this.value.toLowerCase().trim();
        let matchCount = 0;

        cards.forEach(card => {
          const title = card.querySelector(".card-title").textContent.toLowerCase();
          const text = card.querySelector(".card-text").textContent.toLowerCase();
          const match = title.includes(query) || text.includes(query);

          card.parentElement.style.display = match || query === "" ? "block" : "none";
          if (match) matchCount++;
        });

        cardContainer.classList.remove("justify-content-center", "row");

        if (matchCount === 1) {
          cardContainer.classList.add("d-flex", "justify-content-center", "flex-wrap");
        } else {
          cardContainer.className = "row g-4";
        }
      });
    });
  </script>

</body>
</html>
