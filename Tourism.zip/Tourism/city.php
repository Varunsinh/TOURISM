<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>City Sightseeing - IndiYatri</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .tour-card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .tour-card:hover {
      transform: scale(1.05);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
    }

    .tour-card img {
      height: 220px;
      object-fit: cover;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
    }

    .price {
      font-weight: bold;
      color: #28a745;
    }

    .book-btn {
      background: linear-gradient(135deg, #ff5722, #ff8a50);
      color: #fff;
      border: none;
      padding: 8px 20px;
      border-radius: 30px;
      font-weight: 500;
      transition: all 0.3s ease;
    }

    .book-btn:hover {
      background: linear-gradient(135deg, #e64a19, #ff7043);
      transform: scale(1.05);
      box-shadow: 0 8px 15px rgba(255, 87, 34, 0.2);
    }

    .row.g-4>[class*="col-"] {
      margin-bottom: 30px;
    }

    .crossed-flag {
      font-weight: bold;
      font-size: 28px;
      background: linear-gradient(45deg, #ff9933 0%, #ffffff 50%, #138808 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: inline-block;
    }
  </style>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand crossed-flag" href="#">IndiYatri</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse"
        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="index.php">Services</a>
          </li>
          
          
          
          
          <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact Us</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- City Sightseeing Section -->
  <section class="my-5 py-5 px-3 px-md-5">
    <div class="py-3 text-center">
      <h2>City Sightseeing Tours</h2>
      <p class="text-muted mb-4">Explore the iconic cities of India with guided tours.</p>
      <input id="tourSearch" class="form-control mb-5 mx-auto d-block w-50" type="text" placeholder="Search tours..." />
    </div>

    <div class="container">
      <div id="tourCards" class="row g-4">
        <!-- Row 1 -->
        <div class="col-md-4">
          <div class="card tour-card">
            <img src="image/city_delhi.jpg" alt="Delhi City Tour">
            <div class="card-body">
              <h5 class="card-title">Delhi Heritage Tour</h5>
              <p class="card-text">Visit Red Fort, India Gate, Qutub Minar, and Lotus Temple.</p>
              <p class="price">₹2,000 / person</p>
              <button class="book-btn" onclick="alert('Booking for Delhi Tour coming soon!')">Book Tour</button>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card tour-card">
            <img src="image/city_mumbai.jpg" alt="Mumbai City Tour">
            <div class="card-body">
              <h5 class="card-title">Mumbai City Tour</h5>
              <p class="card-text">Gateway of India, Marine Drive, and Bollywood experience.</p>
              <p class="price">₹2,500 / person</p>
              <button class="book-btn" onclick="alert('Booking for Mumbai Tour coming soon!')">Book Tour</button>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card tour-card">
            <img src="image/city_jaipur.jpg" alt="Jaipur City Tour">
            <div class="card-body">
              <h5 class="card-title">Jaipur Pink City Tour</h5>
              <p class="card-text">Amber Fort, City Palace, and Hawa Mahal exploration.</p>
              <p class="price">₹3,000 / person</p>
              <button class="book-btn" onclick="alert('Booking for Jaipur Tour coming soon!')">Book Tour</button>
            </div>
          </div>
        </div>

        <!-- Row 2 -->
        <div class="col-md-4">
          <div class="card tour-card">
            <img src="image/city_varanasi.jpg" alt="Varanasi City Tour">
            <div class="card-body">
              <h5 class="card-title">Varanasi Spiritual Tour</h5>
              <p class="card-text">Ganga Aarti, Kashi Vishwanath Temple, and boat ride.</p>
              <p class="price">₹2,200 / person</p>
              <button class="book-btn" onclick="alert('Booking for Varanasi Tour coming soon!')">Book Tour</button>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card tour-card">
            <img src="image/city_kolkata.jpg" alt="Kolkata City Tour">
            <div class="card-body">
              <h5 class="card-title">Kolkata Cultural Tour</h5>
              <p class="card-text">Victoria Memorial, Howrah Bridge, and Indian Museum.</p>
              <p class="price">₹2,300 / person</p>
              <button class="book-btn" onclick="alert('Booking for Kolkata Tour coming soon!')">Book Tour</button>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card tour-card">
            <img src="image/city_hyderabad.jpg" alt="Hyderabad City Tour">
            <div class="card-body">
              <h5 class="card-title">Hyderabad Heritage Tour</h5>
              <p class="card-text">Charminar, Golconda Fort, and Ramoji Film City.</p>
              <p class="price">₹2,800 / person</p>
              <button class="book-btn" onclick="alert('Booking for Hyderabad Tour coming soon!')">Book Tour</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer style="background-color: #0f172a; color: #f8fafc; padding: 40px 20px;">
    <div style="max-width: 1000px; margin: auto; text-align: center;">
      <p style="margin-bottom: 25px; color: #94a3b8;">Discover India's vibrant cities with IndiYatri City Tours.</p>
      <div style="margin-bottom: 25px;">
        <a href="/about.php" style="color: #38bdf8; margin: 0 12px;">About</a>
        <a href="/projects.html" style="color: #38bdf8; margin: 0 12px;">Projects</a>
        <a href="/contact.php" style="color: #38bdf8; margin: 0 12px;">Contact</a>
        <a href="/coffee.html" style="color: #38bdf8; margin: 0 12px;">Buy me a ☕</a>
      </div>
      <div style="margin-bottom: 20px;">
        <a href="https://github.com/Varunsinh" target="_blank" style="margin: 0 10px; color: #f8fafc;">GitHub</a>
        <a href="https://www.linkedin.com/in/varunsinh-yadav-22a894213" target="_blank" style="margin: 0 10px; color: #f8fafc;">LinkedIn</a>
        <a href="mailto:varunsinhyadav50@gmail.com" style="margin: 0 10px; color: #f8fafc;">Email</a>
      </div>
      <p style="font-size: 14px; color: #64748b;">
        &copy; 2025 IndiYatri — City Sightseeing Tours 🚍
      </p>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Live Search -->
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const searchInput = document.getElementById("tourSearch");
      const cardContainer = document.getElementById("tourCards");
      const cards = document.querySelectorAll(".tour-card");

      searchInput.addEventListener("input", function() {
        const query = this.value.toLowerCase().trim();
        let matchCount = 0;

        cards.forEach(card => {
          const title = card.querySelector(".card-title").textContent.toLowerCase();
          const text = card.querySelector(".card-text").textContent.toLowerCase();
          const match = title.includes(query) || text.includes(query);

          card.parentElement.style.display = match || query === "" ? "block" : "none";
          if (match) matchCount++;
        });

        cardContainer.classList.remove("justify-content-center", "row");

        if (matchCount === 1) {
          cardContainer.classList.add("d-flex", "justify-content-center", "flex-wrap");
        } else {
          cardContainer.className = "row g-4";
        }
      });
    });
  </script>

</body>
</html>
