<?php

// Connect to MySQL
$con = mysqli_connect('localhost', 'root', '');

if ($con) {
    echo "Connection successful<br>";
} else {
    die("Connection failed: " . mysqli_connect_error());
}

// Select database
mysqli_select_db($con, 'userinfo');

// Escape inputs to avoid SQL errors and injection
$username = mysqli_real_escape_string($con, $_POST['username']);
$email    = mysqli_real_escape_string($con, $_POST['email']);
$mobile   = mysqli_real_escape_string($con, $_POST['mobile']);
$comment  = mysqli_real_escape_string($con, $_POST['comment']);

// Build SQL query
$query = "INSERT INTO user (user, email, mobile, comment) 
          VALUES ('$username', '$email', '$mobile', '$comment')";

// Run the query
if (mysqli_query($con, $query)) {
    echo "Data inserted successfully";
} else {
    echo "Error: " . mysqli_error($con);
}

// Debug: show the actual query (optional)
echo "<br>Query: $query";

header('location:index.php');

?>
