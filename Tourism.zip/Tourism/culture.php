<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Culture - IndiYatri</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .culture-card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .culture-card:hover {
      transform: scale(1.05);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
    }

    .culture-card img {
      height: 220px;
      object-fit: cover;
    }

    .card-body h5 {
      font-weight: bold;
    }

    .search-btn {
      background: linear-gradient(135deg, #1e90ff, #00bfff);
      color: #fff;
      border: none;
      padding: 8px 20px;
      border-radius: 30px;
      font-weight: 500;
      transition: all 0.3s ease;
    }

    .search-btn:hover {
      background: linear-gradient(135deg, #005cbf, #0096c7);
      transform: scale(1.05);
      box-shadow: 0 8px 15px rgba(0, 123, 255, 0.2);
    }

    .row.g-4>[class*="col-"] {
      margin-bottom: 30px;
    }

    .crossed-flag {
      font-weight: bold;
      font-size: 28px;
      background: linear-gradient(45deg, #ff9933 0%, #ffffff 50%, #138808 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: inline-block;
    }
  </style>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand crossed-flag" href="#">IndiYatri</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse"
        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php">Services</a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact Us</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Culture Section -->
  <section class="my-5 py-5 px-3 px-md-5">
    <div class="py-3 text-center">
      <h2>Explore Indian Culture</h2>
      <p class="text-muted mb-4">Dive into the rich traditions, festivals, and heritage of India.</p>
      <input id="cultureSearch" class="form-control mb-5 mx-auto d-block w-50" type="text" placeholder="Search culture..." />
    </div>

    <div class="container">
      <div id="cultureCards" class="row g-4">
        <!-- Row 1 -->
        <div class="col-md-4">
          <div class="card culture-card" onclick="window.open('https://www.google.com/search?q=Diwali+Festival', '_blank')" style="cursor: pointer;">
            <img src="image/diwali.jpeg" class="card-img-top" alt="Diwali Festival">
            <div class="card-body">
              <h5 class="card-title">Diwali Festival</h5>
              <p class="card-text">The festival of lights, celebrated with diyas, sweets, and fireworks.</p>
              <p><a href="https://www.google.com/maps?q=India" target="_blank" class="text-primary">📍Celebrated Across India</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card culture-card" onclick="window.open('https://www.google.com/search?q=Kathak+Dance', '_blank')" style="cursor: pointer;">
            <img src="image/khatak.jpeg" class="card-img-top" alt="Kathak Dance">
            <div class="card-body">
              <h5 class="card-title">Kathak Dance</h5>
              <p class="card-text">A classical dance form known for storytelling through graceful movements.</p>
              <p><a href="https://www.google.com/maps?q=Lucknow" target="_blank" class="text-primary">📍Origin: Uttar Pradesh</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card culture-card" onclick="window.open('https://www.google.com/search?q=Holi+Festival', '_blank')" style="cursor: pointer;">
            <img src="image/holi.jpg" class="card-img-top" alt="Holi Festival">
            <div class="card-body">
              <h5 class="card-title">Holi Festival</h5>
              <p class="card-text">The festival of colors, symbolizing love, joy, and the victory of good over evil.</p>
              <p><a href="https://www.google.com/maps?q=Vrindavan" target="_blank" class="text-primary">📍Famous in: Vrindavan & Mathura</a></p>
            </div>
          </div>
        </div>

        <!-- Row 2 -->
        <div class="col-md-4">
          <div class="card culture-card" onclick="window.open('https://www.google.com/search?q=Bharatanatyam+Dance', '_blank')" style="cursor: pointer;">
            <img src="image/bharatanatyam.jpg" class="card-img-top" alt="Bharatanatyam Dance">
            <div class="card-body">
              <h5 class="card-title">Bharatanatyam</h5>
              <p class="card-text">A classical dance form of Tamil Nadu blending devotion and art.</p>
              <p><a href="https://www.google.com/maps?q=Tamil+Nadu" target="_blank" class="text-primary">📍Origin: Tamil Nadu</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card culture-card" onclick="window.open('https://www.google.com/search?q=Indian+Cuisine', '_blank')" style="cursor: pointer;">
            <img src="image/cuisine.jpg" class="card-img-top" alt="Indian Cuisine">
            <div class="card-body">
              <h5 class="card-title">Indian Cuisine</h5>
              <p class="card-text">A flavorful journey through spices, sweets, and diverse regional dishes.</p>
              <p><a href="https://www.google.com/maps?q=India" target="_blank" class="text-primary">📍Available Nationwide</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card culture-card" onclick="window.open('https://www.google.com/search?q=Pushkar+Camel+Fair', '_blank')" style="cursor: pointer;">
            <img src="image/pushkar.jpg" class="card-img-top" alt="Pushkar Camel Fair">
            <div class="card-body">
              <h5 class="card-title">Pushkar Camel Fair</h5>
              <p class="card-text">A unique cultural event with livestock trading, folk music, and festivities.</p>
              <p><a href="https://www.google.com/maps?q=Pushkar" target="_blank" class="text-primary">📍Pushkar, Rajasthan</a></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer style="background-color: #0f172a; color: #f8fafc; padding: 40px 20px;">
    <div style="max-width: 1000px; margin: auto; text-align: center;">
      <p style="margin-bottom: 25px; color: #94a3b8;">Celebrating India's culture, heritage & traditions.</p>
      <div style="margin-bottom: 25px;">
        <a href="/about.php" style="color: #38bdf8; margin: 0 12px;">About</a>
        <a href="/projects.html" style="color: #38bdf8; margin: 0 12px;">Projects</a>
        <a href="/contact.php" style="color: #38bdf8; margin: 0 12px;">Contact</a>
        <a href="/coffee.html" style="color: #38bdf8; margin: 0 12px;">Buy me a ☕</a>
      </div>
      <div style="margin-bottom: 20px;">
        <a href="https://github.com/Varunsinh" target="_blank" style="margin: 0 10px; color: #f8fafc;">GitHub</a>
        <a href="https://www.linkedin.com/in/varunsinh-yadav-22a894213" target="_blank" style="margin: 0 10px; color: #f8fafc;">LinkedIn</a>
        <a href="mailto:varunsinhyadav50@gmail.com" style="margin: 0 10px; color: #f8fafc;">Email</a>
      </div>
      <p style="font-size: 14px; color: #64748b;">
        &copy; 2025 IndiYatri — Celebrating Indian Culture 🌸
      </p>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Live Search -->
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const searchInput = document.getElementById("cultureSearch");
      const cardContainer = document.getElementById("cultureCards");
      const cards = document.querySelectorAll(".culture-card");

      searchInput.addEventListener("input", function() {
        const query = this.value.toLowerCase().trim();
        let matchCount = 0;

        cards.forEach(card => {
          const title = card.querySelector(".card-title").textContent.toLowerCase();
          const text = card.querySelector(".card-text").textContent.toLowerCase();
          const match = title.includes(query) || text.includes(query);

          card.parentElement.style.display = match || query === "" ? "block" : "none";
          if (match) matchCount++;
        });

        cardContainer.classList.remove("justify-content-center", "row");

        if (matchCount === 1) {
          cardContainer.classList.add("d-flex", "justify-content-center", "flex-wrap");
        } else {
          cardContainer.className = "row g-4";
        }
      });
    });
  </script>

</body>
</html>
