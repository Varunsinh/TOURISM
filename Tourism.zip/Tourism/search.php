<?php
if (isset($_GET['query'])) {
    $query = strtolower(trim($_GET['query']));
    $results = [];

    // Dummy search database (you can later move this to a text file or DB)
    $pages = [
        "yatras" => "Spiritual journeys across India’s sacred destinations.",
        "advanture" => "Thrilling experiences in mountains, rivers, and forests.",
        "heritage" => "Explore India’s rich history, architecture, and traditions.",
        "nature" => "Experience India’s wild beauty with guided nature tours.",
        "hotel" => "Comfortable and affordable stays across India.",
        "sightseeing" => "Guided tours to major cities and local gems.",
        "kashmir" => "Stepped in Heaven of the Planet!",
        "kerela" => "The Land of Beauty and Wonders!",
        "rajasthan" => "Thank you, Royals!"
    ];

    // Search logic
    foreach ($pages as $title => $description) {
        if (strpos($title, $query) !== false || strpos(strtolower($description), $query) !== false) {
            $results[$title] = $description;
        }
    }
} else {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Search Results</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-5">
        <h2>Search Results for "<?php echo htmlspecialchars($query); ?>"</h2>
        <hr>
        <?php if (!empty($results)): ?>
            <div class="list-group">
                <?php foreach ($results as $title => $description): ?>
                    <a href="<?php echo $title; ?>.php" class="list-group-item list-group-item-action">
                        <h5 class="mb-1 text-capitalize"><?php echo $title; ?></h5>
                        <p class="mb-1"><?php echo $description; ?></p>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-warning mt-4">No results found for "<?php echo htmlspecialchars($query); ?>"</div>
        <?php endif; ?>
    </div>
</body>

</html>