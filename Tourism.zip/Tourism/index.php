<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>IndiYatri</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Original CSS and Bootstrap -->
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap" rel="stylesheet">

  <style>
    /* Your original styles and new modal styling */
    .card { height:100%; box-shadow:0 0 10px rgba(0,0,0,0.1); border:none; }
    .card-img-top { height:250px; object-fit:cover; }
    .card-title { font-weight:bold; }
    .search-btn {
      background: linear-gradient(135deg, #007bff, #00bfff);
      color:white; border:none; padding:8px 16px; border-radius:30px;
      transition: background 0.3s ease, transform 0.2s ease;
    }
    .search-btn:hover { background: linear-gradient(135deg,#0056b3,#0096c7); transform:scale(1.05); }
    .crossed-flag {
      font-weight:bold; font-size:28px;
      background: linear-gradient(45deg,#ff9933 0%,#ffffff 50%,#138808 100%);
      -webkit-background-clip:text; -webkit-text-fill-color:transparent;
      display:inline-block;
    }
    .aboutimg { border-radius:15px; }
    .service-card {
      transition:transform 0.3s ease, box-shadow 0.3s ease;
      border-radius:10px; overflow:hidden;
    }
    .service-card:hover {
      transform:scale(1.05); box-shadow:0 12px 25px rgba(0,0,0,0.2); z-index:1;
    }
    .card-img-top { height:220px; object-fit:cover; }

    /* Modal styling */
    .modal-header { background-color:#343a40; color:white; }
    .form-control { border-radius:0.4rem; }
    .modal-body input { margin-bottom:10px; }
    .modal-footer .btn { min-width:100px; }
  </style>
</head>

<body>
  <!-- Navbar with integrated Login/Signup buttons -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand crossed-flag" href="#">IndiYatri</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="">Services</a></li>
          <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
          <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
        </ul>
       <form class="form-inline my-2 my-lg-0" onsubmit="return handleSearch(event)">
  <input class="form-control mr-sm-2" type="search" id="searchInput" placeholder="Search..." required>
  <button class="btn search-btn my-2 my-sm-0" type="submit">Search</button>
</form>


        <button class="btn btn-outline-light ml-2" data-toggle="modal" data-target="#authModal">Login / Signup</button>

      </div>
    </div>
  </nav>

  <!-- Original carousel and sections -->
  <div id="demo" class="carousel slide" data-ride="carousel">
    <ul class="carousel-indicators">
      <li data-target="#demo" data-slide-to="0" class="active"></li>
      <li data-target="#demo" data-slide-to="1"></li>
      <li data-target="#demo" data-slide-to="2"></li>
    </ul>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="image/03.jpg" alt="Kashmir" width="1100" height="500">
        <div class="carousel-caption"><h3>Pahelgam,Kashmir</h3><p>Stepped in Heaven of the Planet!</p></div>
      </div>
      <div class="carousel-item">
        <img src="image/05.jpg" alt="Rajesthan" width="1100" height="500">
        <div class="carousel-caption"><h3>Rajesthan</h3><p>Thank you, Royals!</p></div>
      </div>
      <div class="carousel-item">
        <img src="image/08.jpg" alt="Kerela" width="1100" height="500">
        <div class="carousel-caption"><h3>Kerela</h3><p>The Land of Beauty and Wonders!</p></div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#demo" data-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#demo" data-slide="next">
      <span class="carousel-control-next-icon"></span>
    </a>
  </div>

  <section class="my-5"  id="about">
    <div class="py-5"><h2 class="text-center">About Us</h2></div>
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-12">
          <img src="image/09.jpg" class="img-fluid aboutimg rounded" alt="About Us">
        </div>
        <div class="col-lg-6 col-md-6 col-12">
          <h2 class="display-4">We are IndiYatri!</h2>
          <p class="py-5">IndiYatri is your trusted travel companion for discovering the heart and soul of India. From the majestic Himalayas to serene beaches, from vibrant festivals to ancient temples — we curate unforgettable journeys that let you truly experience India’s diversity.</p>
          <a href="about.php" class="btn btn-success">check more</a>
        </div>
      </div>
    </div>
  </section>

  <section class="my-5 py-5 px-3 px-md-5" id="services">
    <div class="py-5"><h2 class="text-center">Our Services</h2></div>
    <div class="row g-4 mb-4">
      <!-- Service cards -->
      <div class="col-lg-4 col-md-4 col-12 d-flex"><div class="card w-100 service-card">
        <img class="card-img-top" src="image/11.jpg" alt="Yatras">
        <div class="card-body d-flex flex-column">
          <h4 class="card-title">Yatras</h4><p class="card-text">Spiritual journeys across India’s sacred destinations.</p>
          <a href="yatras.php" class="btn btn-primary btn-sm mt-auto">Explore here</a>
        </div>
      </div></div>

      <div class="col-lg-4 col-md-4 col-12 d-flex"><div class="card w-100 service-card">
        <img class="card-img-top" src="image/12.jpg" alt="Adventure trips">
        <div class="card-body d-flex flex-column">
          <h4 class="card-title">Adventure Trips</h4><p class="card-text">Thrilling experiences in mountains, rivers, and forests.</p>
          <a href="advanture.php" class="btn btn-primary btn-sm mt-auto">Explore here</a>
        </div>
      </div></div>

      <div class="col-lg-4 col-md-4 col-12 d-flex"><div class="card w-100 service-card">
        <img class="card-img-top" src="image/13.jpg" alt="Heritage & Culture">
        <div class="card-body d-flex flex-column">
          <h4 class="card-title">Heritage & Culture</h4><p class="card-text">Explore India’s rich history, architecture, and traditions.</p>
          <a href="#" class="btn btn-primary btn-sm mt-auto">See Profile</a>
        </div>
      </div></div>
    </div>

    <div class="row g-4">
      <div class="col-lg-4 col-md-4 col-12 d-flex"><div class="card w-100 service-card">
        <img class="card-img-top" src="image/14.jpg" alt="Nature & Wildlife">
        <div class="card-body d-flex flex-column">
          <h4 class="card-title">Nature & Wildlife</h4><p class="card-text">Experience India’s wild beauty with guided nature tours.</p>
          <a href="#" class="btn btn-primary btn-sm mt-auto">See Profile</a>
        </div>
      </div></div>

      <div class="col-lg-4 col-md-4 col-12 d-flex"><div class="card w-100 service-card">
        <img class="card-img-top" src="image/15.jpg" alt="Hotel Bookings">
        <div class="card-body d-flex flex-column">
          <h4 class="card-title">Hotel Bookings</h4><p class="card-text">Comfortable and affordable stays across India.</p>
          <a href="#" class="btn btn-primary btn-sm mt-auto">See Profile</a>
        </div>
      </div></div>

      <div class="col-lg-4 col-md-4 col-12 d-flex"><div class="card w-100 service-card">
        <img class="card-img-top" src="image/16.jpg" alt="City Sightseeing">
        <div class="card-body d-flex flex-column">
          <h4 class="card-title">City Sightseeing</h4><p class="card-text">Guided tours to major cities and local gems.</p>
          <a href="#" class="btn btn-primary btn-sm mt-auto">See Profile</a>
        </div>
      </div></div>
    </div>
  </section>

  <section class="my-5" id="contact">
    <div class="py-5"><h2 class="text-center">Contact Us</h2></div>
    <div class="w-50 m-auto">
      <form method="post" action="userinfo.php">
        <div class="form-group"><label>Username:</label><input type="text" name="username" class="form-control"></div>
        <div class="form-group"><label>Email Id:</label><input type="text" name="email" class="form-control"></div>
        <div class="form-group"><label>Mobile:</label><input type="text" name="mobile" class="form-control"></div>
        <div class="form-group"><label>Comments:</label><textarea name="comment" class="form-control"></textarea></div>
        <button type="submit" class="btn btn-success">Submit</button>
      </form>
    </div>
  </section>

  <footer style="background-color:#0f172a;color:#f8fafc;padding:40px 20px;">
    <div style="max-width:1000px;margin:auto;text-align:center;">
      <p style="margin-bottom:25px;color:#94a3b8;">I write code, design interfaces, seamless user experiences Let's connect.</p>
      <div style="margin-bottom:25px;">
        <a href="/about.html" style="color:#38bdf8;margin:0 12px;">About</a>
        <a href="/projects.html" style="color:#38bdf8;margin:0 12px;">Projects</a>
        <a href="/contact.html" style="color:#38bdf8;margin:0 12px;">Contact</a>
        <a href="/coffee.html" style="color:#38bdf8;margin:0 12px;">Buy me a ☕</a>
      </div>
      <div style="margin-bottom:20px;">
        <a href="https://github.com/Varunsinh" target="_blank" style="color:#f8fafc;margin:0 10px;">GitHub</a>
        <a href="https://www.linkedin.com/in/varunsinh-yadav-22a894213" target="_blank" style="color:#f8fafc;margin:0 10px;">LinkedIn</a>
        <a href="mailto:varunsinhyadav50@gmail.com" style="color:#f8fafc;margin:0 10px;">Email</a>
      </div>
      <p style="font-size:14px;color:#64748b;">&copy; 2025 IndiYatri — Coded with 💻, styled with 🎨.</p>
    </div>
  </footer>

  <!-- Modals -->
  <!-- Combined Login/Signup Modal -->
<div class="modal fade" id="authModal" tabindex="-1" role="dialog" aria-labelledby="authModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title" id="authModalLabel">Welcome to IndiYatri</h5>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
        <!-- Nav Tabs -->
        <ul class="nav nav-tabs mb-3" id="authTabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="login-tab" data-toggle="tab" href="#loginTab" role="tab">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="signup-tab" data-toggle="tab" href="#signupTab" role="tab">Signup</a>
          </li>
        </ul>

        <div class="tab-content" id="authTabsContent">
          <!-- Login Form -->
          <div class="tab-pane fade show active" id="loginTab" role="tabpanel">
            <form method="post" action="login.php">
              <div class="form-group">
                <input type="text" name="username" class="form-control" placeholder="Username" required>
              </div>
              <div class="form-group">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
              </div>
              <div class="text-right">
                <button type="submit" class="btn btn-primary">Login</button>
              </div>
            </form>
          </div>

          <!-- Signup Form -->
          <div class="tab-pane fade" id="signupTab" role="tabpanel">
            <form method="post" action="signup.php">
              <div class="form-group">
                <input type="text" name="username" class="form-control" placeholder="Username" required>
              </div>
              <div class="form-group">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
              </div>
              <div class="text-right">
                <button type="submit" class="btn btn-success">Signup</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

  <!-- JS -->
   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
  


  <script>
  function handleSearch(event) {
    event.preventDefault();
    const query = document.getElementById('searchInput').value.toLowerCase();

    const sectionMap = {
      'about': 'about',
      'services': 'services',
      'yatras': 'services',
      'adventure': 'services',
      'heritage': 'services',
      'wildlife': 'services',
      'nature': 'services',
      'hotel': 'services',
      'sightseeing': 'services',
      'contact': 'contact',
      'support': 'contact',
      'reach': 'contact'
    };

    let found = false;

    for (const keyword in sectionMap) {
      if (query.includes(keyword)) {
        const sectionId = sectionMap[keyword];
        const section = document.getElementById(sectionId);
        if (section) {
          // Smooth scroll using jQuery
          $('html, body').animate({
            scrollTop: $('#' + sectionId).offset().top
          }, 800); // duration in ms
          found = true;
          break;
        }
      }
    }

    if (!found) {
      alert("Sorry! No matching section found.");
    }

    return false;
  }
</script>


</body>
</html>
