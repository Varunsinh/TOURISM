<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Trips - IndiYatri</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet"/>

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .trip-card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      cursor: pointer;
    }

    .trip-card:hover {
      transform: scale(1.05);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
    }

    .trip-card img {
      height: 220px;
      object-fit: cover;
    }

    .card-body h5 {
      font-weight: bold;
    }

     .search-btn {
      background: linear-gradient(135deg, #1e90ff, #00bfff);
      color: #fff;
      border: none;
      padding: 8px 20px;
      border-radius: 30px;
      font-weight: 500;
      transition: all 0.3s ease;
    }

    .search-btn:hover {
      background: linear-gradient(135deg, #005cbf, #0096c7);
      transform: scale(1.05);
      box-shadow: 0 8px 15px rgba(0, 123, 255, 0.2);
    }

    .row.g-4 > [class*="col-"] {
      margin-bottom: 30px;
    }

    .crossed-flag {
      font-weight: bold;
      font-size: 28px;
      background: linear-gradient(45deg, #ff9933 0%, #ffffff 50%, #138808 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: inline-block;
    }
  </style>
</head>

<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand crossed-flag" href="#">IndiYatri</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse"
      data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
      aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="yatras.php">Services</a></li>
        <li class="nav-item"><a class="nav-link active" href="trips.php">Trips</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Trips Section -->
<section class="my-5 py-5 px-3 px-md-5">
  <div class="py-3 text-center">
    <h2>Adventure Trips</h2>
    <p class="text-muted mb-4">Explore thrilling destinations across India for unforgettable adventures.</p>
    <input id="tripSearch" class="form-control mb-5 mx-auto d-block w-50" type="text" placeholder="Search for a Trip..." />
  </div>

  <div class="container">
    <div id="tripCards" class="row g-4">
      <!-- Trip 1 -->
      <div class="col-md-4">
        <div class="card trip-card" onclick="window.open('https://www.google.com/search?q=Manali+Trekking+Trip', '_blank')">
          <img src="image/manali.jpg" class="card-img-top" alt="Manali Trek">
          <div class="card-body">
            <h5 class="card-title">Manali Trekking</h5>
            <p class="card-text">Discover scenic trails and snow-capped peaks in the Himalayas.</p>
            <p><a href="https://www.google.com/maps?q=Manali+India" target="_blank" class="text-primary">📍Location</a></p>
          </div>
        </div>
      </div>

      <!-- Trip 2 -->
      <div class="col-md-4">
        <div class="card trip-card" onclick="window.open('https://www.google.com/search?q=Rishikesh+River+Rafting', '_blank')">
          <img src="image/rafting.jpg" class="card-img-top" alt="Rafting">
          <div class="card-body">
            <h5 class="card-title">Rishikesh River Rafting</h5>
            <p class="card-text">Feel the thrill as you navigate the powerful rapids of the Ganges.</p>
            <p><a href="https://www.google.com/maps?q=Rishikesh" target="_blank" class="text-primary">📍Location</a></p>
          </div>
        </div>
      </div>

      <!-- Trip 3 -->
      <div class="col-md-4">
        <div class="card trip-card" onclick="window.open('https://www.google.com/search?q=Bir+Billing+Paragliding', '_blank')">
          <img src="image/paragliding.jpg" class="card-img-top" alt="Paragliding">
          <div class="card-body">
            <h5 class="card-title">Bir Billing Paragliding</h5>
            <p class="card-text">Soar high above the valleys in India’s paragliding capital.</p>
            <p><a href="https://www.google.com/maps?q=Bir+Billing" target="_blank" class="text-primary">📍Location</a></p>
          </div>
        </div>
      </div>

      <!-- Trip 4 -->
      <div class="col-md-4">
        <div class="card trip-card" onclick="window.open('https://www.google.com/search?q=Thar+Desert+Safari+Jaisalmer', '_blank')">
          <img src="image/desert.jpg" class="card-img-top" alt="Desert Safari">
          <div class="card-body">
            <h5 class="card-title">Thar Desert Safari</h5>
            <p class="card-text">Experience camel rides, cultural shows, and desert nights in Jaisalmer.</p>
            <p><a href="https://www.google.com/maps?q=Thar+Desert+Jaisalmer" target="_blank" class="text-primary">📍Location</a></p>
          </div>
        </div>
      </div>

      <!-- Trip 5 -->
      <div class="col-md-4">
        <div class="card trip-card" onclick="window.open('https://www.google.com/search?q=Scuba+Diving+Andaman+Islands', '_blank')">
          <img src="image/scuba.jpg" class="card-img-top" alt="Scuba Diving">
          <div class="card-body">
            <h5 class="card-title">Andaman Scuba Diving</h5>
            <p class="card-text">Dive into turquoise waters and discover marine life at Havelock.</p>
            <p><a href="https://www.google.com/maps?q=Havelock+Island" target="_blank" class="text-primary">📍Location</a></p>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card trip-card" onclick="window.open('https://www.google.com/search?q=Ladakh+Bike+Trip', '_blank')">
          <img src="image/ladakh.jpg" class="card-img-top" alt="Leh-Ladakh">
          <div class="card-body">
            <h5 class="card-title">Leh-Ladakh Bike Riding</h5>
            <p class="card-text">Ride across Ladakh’s rugged passes on two wheels.</p>
            <p><a href="https://maps.app.goo.gl/WAZkaqkPr2em1crA8" target="_blank" class="text-primary">📍Location</a></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<footer style="background-color: #0f172a; color: #f8fafc; padding: 40px 20px; font-family: 'Segoe UI', sans-serif;">
    <div style="max-width: 1000px; margin: auto; text-align: center;">
      <p style="margin-bottom: 25px; color: #94a3b8;">I write code, design interfaces, seamless user experiences! Let's connect.</p>
      <div style="margin-bottom: 25px;">
        <a href="/about.php" style="color: #38bdf8; margin: 0 12px; text-decoration: none;">About</a>
        <a href="/projects.html" style="color: #38bdf8; margin: 0 12px; text-decoration: none;">Projects</a>
        <a href="/contact.php" style="color: #38bdf8; margin: 0 12px; text-decoration: none;">Contact</a>
        <a href="/coffee.html" style="color: #38bdf8; margin: 0 12px; text-decoration: none;">Buy me a ☕</a>
      </div>
      <div style="margin-bottom: 20px;">
        <a href="https://github.com/Varunsinh" target="_blank" style="margin: 0 10px; color: #f8fafc;">GitHub</a>
        <a href="https://www.linkedin.com/in/varunsinh-yadav-22a894213" target="_blank" style="margin: 0 10px; color: #f8fafc;">LinkedIn</a>
        <a href="mailto:varunsinhyadav50@gmail.com" style="margin: 0 10px; color: #f8fafc;">Email</a>
      </div>
      <p style="font-size: 14px; color: #64748b;">
        &copy; 2025 IndiYatri — Coded with 💻, styled with 🎨.
      </p>
    </div>
  </footer>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Live Search Filter for Trips -->
<script>
document.addEventListener("DOMContentLoaded", function () {
  const searchInput = document.getElementById("tripSearch");
  const cardContainer = document.getElementById("tripCards");
  const cards = document.querySelectorAll(".trip-card");

  searchInput.addEventListener("input", function () {
    const query = this.value.toLowerCase().trim();
    let matchCount = 0;

    cards.forEach(card => {
      const title = card.querySelector(".card-title").textContent.toLowerCase();
      const text = card.querySelector(".card-text").textContent.toLowerCase();
      const match = title.includes(query) || text.includes(query);

      card.parentElement.style.display = match || query === "" ? "block" : "none";
       if (match) matchCount++;
    });
    // Remove any previous centering
      cardContainer.classList.remove("justify-content-center", "row");

      if (matchCount === 1) {
        cardContainer.classList.add("d-flex", "justify-content-center", "flex-wrap");
      } else {
        cardContainer.className = "row g-4";
      }
  });
});
</script>

</body>
</html>
