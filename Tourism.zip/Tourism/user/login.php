<?php
// Always start session if needed (optional)
// session_start();

$login_error = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $valid_username = "$username";
    $valid_password = "$password";

    if ($username === $valid_username && $password === $valid_password) {
        header("Location: index.php");
        exit();
    } else {
        $login_error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            background-image: url('image/25.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            height: 80vh;
            margin: 0;
            background-color: rgb(221, 227, 178);
            font-family: mall-caps slashed-zero;
            ;
        }

        .login-box {
            background: rgba(223, 223, 223, 0.6);
            height: 315px;
            width: 400px;
            margin: 150px auto;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 20px #aaa;
        }

        input[type='text'],
        input[type='password'] {
            width: 95%;
            padding: 8px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type='submit'] {
            width: 90%;
            padding: 10px;
            background-color: #17a589;
            color: white;
            border: none;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
        }

        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="login-box">
        <h2 style="text-align:center;font-size:xx-large">Login</h2>
        <form method="post">
            <label>Username:</label>
            <input type="text" name="username" required>

            <label>Password:</label>
            <input type="password" name="password" required>

            <div style="text-align: center;">
                <input type="submit" name="login" value="Login">
            </div>
        </form>

        <?php
        if (!empty($login_error)) {
            echo "<p class='error'>$login_error</p>";
        }
        ?>
    </div>
</body>

</html>