<?php
require "../config.php"; // Database Connection

// Fetch all City Tours from DB
$cityTours = mysqli_query($conn, "SELECT * FROM cities ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>City Sightseeing - IndiYatri</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .trip-card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .trip-card:hover {
      transform: scale(1.05);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
    }

    .trip-card img {
      height: 220px;
      object-fit: cover;
      border-radius: 10px 10px 0 0;
    }

    .card-body h5 {
      font-weight: bold;
    }

    .row.g-4>[class*="col-"] {
      margin-bottom: 30px;
    }
  </style>
</head>

<body>
  <!-- Navbar -->
  <?php include 'header.php'; ?>

  <!-- City Sightseeing Section -->
  <section class="my-5 py-5 px-3 px-md-5">
    <div class="py-3 text-center">
      <h2>City Sightseeing</h2>
      <p class="text-muted mb-4">Discover India’s cultural and historic cities with guided tours.</p>
      <input id="citySearch" class="form-control mb-5 mx-auto d-block w-50" type="text" placeholder="Search for a City..." />
    </div>

    <div class="container">
      <div id="cityCards" class="row g-4">

        <!-- Dynamic City Cards -->
        <?php while ($city = mysqli_fetch_assoc($cityTours)) : ?>
          <div class="col-md-4 city-item">
            <div class="card trip-card">
              <?php
                $imgFile = $city['image'] ?? '';
                $imgPath = "../uploads/cities/" . $imgFile;
                if (!empty($imgFile) && file_exists(__DIR__ . "/../uploads/cities/" . $imgFile)) :
              ?>
                <img src="<?= htmlspecialchars($imgPath) ?>" class="card-img-top" alt="<?= htmlspecialchars($city['name']) ?>">
              <?php else: ?>
                <img src="https://via.placeholder.com/400x220?text=No+Image" class="card-img-top" alt="No image">
              <?php endif; ?>
              <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($city['name']) ?></h5>
                <p class="card-text"><?= htmlspecialchars($city['description']) ?></p>
                <a href="city_booking.php?id=<?= $city['id'] ?>" class="btn btn-success btn-sm">Book Now</a>
              </div>
            </div>
          </div>
        <?php endwhile; ?>

      </div>
    </div>
  </section>

  <!-- Footer -->
  <?php include 'footer.php'; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Live Search -->
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const searchInput = document.getElementById("citySearch");
      const items = document.querySelectorAll(".city-item");
      const row = document.getElementById("cityCards");

      searchInput.addEventListener("input", function () {
        const q = this.value.toLowerCase().trim();
        let shown = 0;

        items.forEach(card => {
          const title = card.querySelector(".card-title").textContent.toLowerCase();
          const text = card.querySelector(".card-text").textContent.toLowerCase();
          const match = title.includes(q) || text.includes(q);

          card.style.display = match ? "block" : "none";
          if (match) shown++;
        });

        // Center if only 1 visible card
        if (shown === 1) {
          row.classList.add("justify-content-center");
        } else {
          row.classList.remove("justify-content-center");
        }
      });
    });
  </script>

</body>
</html>
