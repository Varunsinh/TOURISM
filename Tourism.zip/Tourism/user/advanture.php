<?php
require "../config.php"; // Database Connection

// Fetch all Adventures from DB
$adventures = mysqli_query($conn, "SELECT * FROM adventures ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Adventure Trips - IndiYatri</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .trip-card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .trip-card:hover {
      transform: scale(1.05);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
    }

    .trip-card img {
      height: 220px;
      object-fit: cover;
      border-radius: 10px 10px 0 0;
    }

    .card-body h5 {
      font-weight: bold;
    }

    .row.g-4>[class*="col-"] {
      margin-bottom: 30px;
    }
  </style>
</head>

<body>
  <!-- Navbar -->
  <?php include 'header.php'; ?>

  <!-- Adventure Trips Section -->
  <section class="my-5 py-5 px-3 px-md-5">
    <div class="py-3 text-center">
      <h2>Adventure Trips</h2>
      <p class="text-muted mb-4">Explore thrilling destinations across India for unforgettable adventures.</p>
      <input id="tripSearch" class="form-control mb-5 mx-auto d-block w-50" type="text"
        placeholder="Search for an Adventure..." />
    </div>

    <div class="container">
      <div id="tripCards" class="row g-4">

        <!-- Dynamic Adventure Cards -->
        <?php while ($adv = mysqli_fetch_assoc($adventures)) : ?>
          <div class="col-md-4 adventure-item">
            <div class="card trip-card">
              <img src="../uploads/adventures/<?php echo htmlspecialchars($adv['image']); ?>" class="card-img-top"
                alt="<?php echo htmlspecialchars($adv['name']); ?>"
                onerror="this.src='https://via.placeholder.com/400x220?text=Image+Not+Found'">
              <div class="card-body">
                <h5 class="card-title"><?php echo htmlspecialchars($adv['name']); ?></h5>
                <p class="card-text"><?php echo htmlspecialchars($adv['description']); ?></p>
                <a href="adv_booking.php?id=<?php echo $adv['id']; ?>" class="btn btn-success btn-sm">Book Now</a>
              </div>
            </div>
          </div>
        <?php endwhile; ?>

      </div>
    </div>
  </section>

  <!-- Footer -->
  <?php include 'footer.php'; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Live Search -->
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const searchInput = document.getElementById("tripSearch");
      const items = document.querySelectorAll(".adventure-item");
      const row = document.getElementById("tripCards");

      searchInput.addEventListener("input", function () {
        const q = this.value.toLowerCase().trim();
        let shown = 0;

        items.forEach(card => {
          const title = card.querySelector(".card-title").textContent.toLowerCase();
          const text = card.querySelector(".card-text").textContent.toLowerCase();
          const match = title.includes(q) || text.includes(q);

          card.style.display = match ? "block" : "none";
          if (match) shown++;
        });

        // Center if only 1 visible card
        if (shown === 1) {
          row.classList.add("justify-content-center");
        } else {
          row.classList.remove("justify-content-center");
        }
      });
    });
  </script>

</body>
</html>
