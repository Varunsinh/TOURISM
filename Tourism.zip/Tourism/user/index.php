<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>IndiYatri</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Original CSS and Bootstrap -->
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap" rel="stylesheet">

  <style>
    /* Your original styles and new modal styling */
    .card {
      height: 100%;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      border: none;
    }

    .card-img-top {
      height: 250px;
      object-fit: cover;
    }

    .card-title {
      font-weight: bold;
    }

    .search-btn {
      background: linear-gradient(135deg, #007bff, #00bfff);
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 30px;
      transition: background 0.3s ease, transform 0.2s ease;
    }

    .search-btn:hover {
      background: linear-gradient(135deg, #0056b3, #0096c7);
      transform: scale(1.05);
    }

    .crossed-flag {
      font-weight: bold;
      font-size: 28px;
      background: linear-gradient(45deg, #ff9933 0%, #ffffff 50%, #138808 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: inline-block;
    }

    .aboutimg {
      border-radius: 15px;
    }

    .service-card {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      border-radius: 10px;
      overflow: hidden;
    }

    .service-card:hover {
      transform: scale(1.05);
      box-shadow: 0 12px 25px rgba(0, 0, 0, 0.2);
      z-index: 1;
    }

    .card-img-top {
      height: 250px;
      object-fit: cover;
    }

    /* Modal styling */
    .modal-header {
      background-color: #343a40;
      color: white;
    }

    .form-control {
      border-radius: 0.4rem;
    }

    .modal-body input {
      margin-bottom: 10px;
    }

    .modal-footer .btn {
      min-width: 100px;
    }
  </style>
</head>

<body>
  <!-- Navbar with integrated Login/Signup buttons -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">

      <!-- Brand on the left -->
      <a class="navbar-brand crossed-flag" href="#">IndiYatri</a>

      <!-- Toggler for mobile -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar content -->
      <div class="collapse navbar-collapse justify-content-between" id="navbarSupportedContent">

        <!-- Centered Links -->
        <ul class="navbar-nav mx-auto">
          <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
          <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
          <li class="nav-item"><a class="nav-link" href="#contact">Contact Us</a></li>

        </ul>

        <!-- Right-side icons -->
        <div class="d-flex align-items-center">

          <!-- Search icon dropdown -->
          <div class="nav-item dropdown">
            <a class="nav-link" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
            </a>
            <div class="dropdown-menu dropdown-menu-right p-2" style="min-width: 250px;">
              <form class="form-inline" onsubmit="return handleSearch(event)">
                <input class="form-control w-100" type="search" id="searchInput" placeholder="Search here..." required>
              </form>
            </div>
          </div>

          <!-- Login/Signup Button -->
          <button class="btn btn-outline-light ml-2" data-toggle="modal" data-target="#authModal">Login / Signup</button>

        </div>

      </div>
    </div>
  </nav>
  <div class="container mt-auto">
    <?php if (isset($_GET['signup']) && $_GET['signup'] === 'success'): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        🎉 Signup successful! You can now login.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php endif; ?>
  </div>

  <!-- Original carousel and sections -->
  <div id="demo" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ul class="carousel-indicators">
      <li data-target="#demo" data-slide-to="0" class="active"></li>
      <li data-target="#demo" data-slide-to="1"></li>
      <li data-target="#demo" data-slide-to="2"></li>
    </ul>


    <div class="carousel-inner">


      <div class="carousel-item active">
        <img src="image/03.jpg"  class="d-block w-100 carousel-img" alt="Kashmir">
        <div class="map-info">
          <div class="map-icon">
            <svg width="24" height="24" fill="none" stroke="white" stroke-width="2"
              stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
              <circle cx="12" cy="10" r="3"></circle>
              <path d="M12 2C8 2 5 5 5 9c0 5 7 13 7 13s7-8 7-13c0-4-3-7-7-7z"></path>
            </svg>
          </div>
          <div class="map-label">Pahelgam, Kashmir © IndiYatri</div>
        </div>
        <div class="carousel-caption">
          <h3>Pahelgam, Kashmir</h3>
          <p>Stepped in Heaven of the Planet!</p>
        </div>
      </div>


      <div class="carousel-item">
        <img src="image/05.jpg"  class="d-block w-100 carousel-img" alt="Rajasthan">
        <div class="map-info">
          <div class="map-icon">
            <svg width="24" height="24" fill="none" stroke="white" stroke-width="2"
              stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
              <circle cx="12" cy="10" r="3"></circle>
              <path d="M12 2C8 2 5 5 5 9c0 5 7 13 7 13s7-8 7-13c0-4-3-7-7-7z"></path>
            </svg>
          </div>
          <div class="map-label">Jaipur, Rajasthan © IndiYatri</div>
        </div>
        <div class="carousel-caption">
          <h3>Jaipur, Rajasthan</h3>
          <p>Royal Heritage in the Desert Land!</p>
        </div>
      </div>


      <div class="carousel-item">
        <img src="image/08.jpg"  class="d-block w-100 carousel-img" alt="Kerala">
        <div class="map-info">
          <div class="map-icon">
            <svg width="24" height="24" fill="none" stroke="white" stroke-width="2"
              stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
              <circle cx="12" cy="10" r="3"></circle>
              <path d="M12 2C8 2 5 5 5 9c0 5 7 13 7 13s7-8 7-13c0-4-3-7-7-7z"></path>
            </svg>
          </div>
          <div class="map-label">Alleppey, Kerala © IndiYatri</div>
        </div>
        <div class="carousel-caption">
          <h3>Alleppey, Kerala</h3>
          <p>Backwaters and Beauty of Nature!</p>
        </div>
      </div>

    </div>


    <a class="carousel-control-prev" href="#demo" data-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#demo" data-slide="next">
      <span class="carousel-control-next-icon"></span>
    </a>
  </div>


  <section class="my-5" id="about">
    <div class="py-5">
      <h2 class="text-center">About Us</h2>
    </div>
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-12">
          <img src="image/09.jpg" class="img-fluid aboutimg rounded" alt="About Us">
        </div>
        <div class="col-lg-6 col-md-6 col-12">
          <h2 class="display-4">We are IndiYatri!</h2>
          <p class="py-5">IndiYatri is your trusted travel companion for discovering the heart and soul of India. From the majestic Himalayas to serene beaches, from vibrant festivals to ancient temples — we curate unforgettable journeys that let you truly experience India’s diversity.</p>
          <a href="about.php" class="btn btn-primary">check more</a>
        </div>
      </div>
    </div>
  </section>

  <section class="my-5 py-5 px-3 px-md-5" id="services">
    <div class="py-5">
      <h2 class="text-center">Our Services</h2>
    </div>
    <div class="row g-4 mb-4">
      <div class="col-lg-4 col-md-4 col-12 d-flex">
        <div class="card w-100 service-card">
          <img class="card-img-top" src="image/11.jpg" alt="Yatras">
          <div class="card-body d-flex flex-column">
            <h4 class="card-title">Yatras</h4>
            <p class="card-text">Spiritual journeys across India’s sacred destinations.</p>
            <a href="yatras.php" class="btn btn-primary btn-sm mt-auto">Explore here</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-12 d-flex">
        <div class="card w-100 service-card">
          <img class="card-img-top" src="image/12.jpg" alt="Adventure trips">
          <div class="card-body d-flex flex-column">
            <h4 class="card-title">Adventure Trips</h4>
            <p class="card-text">Thrilling experiences in mountains, rivers, and forests.</p>
            <a href="advanture.php" class="btn btn-primary btn-sm mt-auto">Explore here</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-12 d-flex">
        <div class="card w-100 service-card">
          <img class="card-img-top" src="image/16.jpg" alt="City Sightseeing">
          <div class="card-body d-flex flex-column">
            <h4 class="card-title">City Sightseeing</h4>
            <p class="card-text">Guided tours to major cities and local gems.</p>
            <a href="city.php" class="btn btn-primary btn-sm mt-auto">Explore here</a>
          </div>
        </div>
      </div>

      
    </div>

    <div class="row g-4">
      <div class="col-lg-4 col-md-4 col-12 d-flex">
        <div class="card w-100 service-card">
          <img class="card-img-top" src="image/14.jpg" alt="Nature & Wildlife">
          <div class="card-body d-flex flex-column">
            <h4 class="card-title">Nature & Wildlife</h4>
            <p class="card-text">Experience India’s wild beauty with guided nature tours.</p>
            <a href="nature.php" class="btn btn-primary btn-sm mt-auto">Explore here</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-12 d-flex">
        <div class="card w-100 service-card">
          <img class="card-img-top" src="image/15.jpg" alt="Hotel Bookings">
          <div class="card-body d-flex flex-column">
            <h4 class="card-title">Hotel Bookings</h4>
            <p class="card-text">Comfortable and affordable stays across India.</p>
            <a href="hotel.php" class="btn btn-primary btn-sm mt-auto">Explore here</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-12 d-flex">
        <div class="card w-100 service-card">
          <img class="card-img-top" src="image/13.jpg" alt="Heritage & Culture">
          <div class="card-body d-flex flex-column">
            <h4 class="card-title">Heritage & Culture</h4>
            <p class="card-text">Explore India’s rich history, architecture, and traditions.</p>
            <a href="culture.php" class="btn btn-primary btn-sm mt-auto">Explore here</a>
          </div>
        </div>
      </div>
      
    </div>
  </section>

  <section class="my-5" id="contact">
    <div class="py-5">
      <h2 class="text-center">Contact Us</h2>
    </div>
    <div class="w-50 m-auto">
      <form method="post" action="userinfo.php">
        <div class="form-group"><label>Username:</label><input type="text" name="username" class="form-control"></div>
        <div class="form-group"><label>Email Id:</label><input type="text" name="email" class="form-control"></div>
        <div class="form-group"><label>Mobile:</label><input type="text" name="mobile" class="form-control"></div>
        <div class="form-group"><label>Comments:</label><textarea name="comment" class="form-control"></textarea></div>
        <button type="submit" class="btn btn-primary">Submit</button>

      </form>
    </div>
  </section>

  <footer>
  <?php include 'footer.php'?>
</footer>
  <!-- Modals -->
  <!-- Combined Login/Signup Modal -->
  <div class="modal fade" id="authModal" tabindex="-1" role="dialog" aria-labelledby="authModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header bg-dark text-white">
          <h5 class="modal-title" id="authModalLabel">Welcome to IndiYatri</h5>
          <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <!-- Nav Tabs -->
          <ul class="nav nav-tabs mb-3" id="authTabs" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" id="login-tab" data-toggle="tab" href="#loginTab" role="tab">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="signup-tab" data-toggle="tab" href="#signupTab" role="tab">Signup</a>
            </li>
          </ul>

          <div class="tab-content" id="authTabsContent">
            <!-- Login Form -->
            <div class="tab-pane fade show active" id="loginTab" role="tabpanel">
              <form method="post" action="login.php">
                <div class="form-group">
                  <input type="text" name="username" class="form-control" placeholder="Username" required>
                </div>
                <div class="form-group">
                  <input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>
                <div class="text-right">
                  <button type="submit" class="btn btn-success">Login</button>
                </div>
              </form>
            </div>

            <!-- Signup Form -->
            <div class="tab-pane fade" id="signupTab">
              <form id="signupForm" method="post">
                <div class="form-group">
                  <input type="text" name="username" class="form-control" placeholder="Username" required>
                </div>
                <div class="form-group">
                  <input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>
                <div id="signupMessage" class="text-success mb-2" style="display:none;"></div>
                <div class="text-right">
                  <button type="submit" class="btn btn-success">Signup</button>
                </div>
              </form>
            </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>

  <!-- JS -->
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>



  <script>
    function handleSearch(event) {
      event.preventDefault();
      const query = document.getElementById('searchInput').value.toLowerCase();

      const sectionMap = {
        'about': 'about',
        'services': 'services',
        'yatras': 'services',
        'adventure': 'services',
        'heritage': 'services',
        'wildlife': 'services',
        'nature': 'services',
        'hotel': 'services',
        'sightseeing': 'services',
        'contact': 'contact',
        'support': 'contact',
        'reach': 'contact'
      };

      let found = false;

      for (const keyword in sectionMap) {
        if (query.includes(keyword)) {
          const sectionId = sectionMap[keyword];
          const section = document.getElementById(sectionId);
          if (section) {
            // Smooth scroll using jQuery
            $('html, body').animate({
              scrollTop: $('#' + sectionId).offset().top
            }, 800); // duration in ms
            found = true;
            break;
          }
        }
      }

      if (!found) {
        alert("Sorry! No matching section found.");
      }

      return false;
    }

  $(document).ready(function () {
  $("#signupForm").on("submit", function (e) {
    e.preventDefault(); // stop normal form submit

    $.ajax({
      type: "POST",
      url: "signup.php",
      data: $(this).serialize(),
      success: function (response) {
        if (response.trim() === "success") {
          $("#signupMessage")
            .text("🎉 Signed up successfully! Please login now.")
            .css("color", "green")
            .fadeIn();

          $("#signupForm")[0].reset(); // clear form

          // ✅ Switch to Login tab automatically
          setTimeout(function () {
            $('#login-tab').tab('show'); // Bootstrap tab switch
            $("#signupMessage").hide(); // hide old message
          }, 1500);
        } else {
          $("#signupMessage")
            .text("❌ Signup failed, please try again.")
            .css("color", "red")
            .fadeIn();
        }
      }
    });
  });
});
  </script>


</body>

</html>