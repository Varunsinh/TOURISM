<footer style="background-color:#0f172a;color:#f8fafc;padding:40px 20px;">
    <div style="max-width:1000px;margin:auto;text-align:center;">
      <p style="margin-bottom:25px;color:#94a3b8;">I write code, design interfaces, seamless user experiences Let's connect.</p>
      <div style="margin-bottom:25px;">
        <a href="/about.html" style="color:#38bdf8;margin:0 12px;">About</a>
        <a href="/projects.html" style="color:#38bdf8;margin:0 12px;">Projects</a>
        <a href="/contact.html" style="color:#38bdf8;margin:0 12px;">Contact</a>

      </div>
      <div style="margin-bottom:20px;">

        <a href="https://www.linkedin.com/in/varunsinh-yadav-22a894213" target="_blank" style="color:#38bdf8;margin:0 12px;">LinkedIn</a>
        <a href="mailto:varunsinhyadav50@gmail.com" style="color:#38bdf8;margin:0 12px;">Email</a>
      </div>
      <p style="font-size:14px;color:#64748b;">&copy; 2025 IndiYatri — Coded with 💻, styled with 🎨.</p>
    </div>
  </footer>