<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contact Us - IndiYatri</title>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .contact-section {
      padding: 60px 0;
      background-color: #f5f5f5;
    }

    .contact-box {
      background: #ffffff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .form-control:focus {
      box-shadow: none;
      border-color: #28a745;
    }

    footer a:hover {
      text-decoration: underline;
    }

    .crossed-flag {
      font-weight: bold;
      font-size: 28px;
      background: linear-gradient(45deg, #ff9933 0%, #ffffff 50%, #138808 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: inline-block;
    }
  </style>
</head>

<body>

  
    <header>
      <?php include 'header.php'?>
    </header>

  <!-- CONTACT FORM -->
  <section class="contact-section">
    <div class="container">
      <div class="text-center mb-4">
        <h2>Contact Us</h2>
        <p class="text-muted">We’d love to hear from you. Send us a message below.</p>
      </div>
      <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="contact-box">
            <form action="userinfo.php" method="POST">
              <div class="form-group">
                <label for="username">Full Name</label>
                <input type="text" class="form-control" id="username" name="username" required>
              </div>
              <div class="form-group">
                <label for="email">Email address</label>
                <input type="email" class="form-control" id="email" name="email" required>
              </div>
              <div class="form-group">
                <label for="mobile">Phone Number</label>
                <input type="tel" class="form-control" id="mobile" name="mobile">
              </div>
              <div class="form-group">
                <label for="comment">Your Message</label>
                <textarea class="form-control" id="comment" name="comment" rows="4" required></textarea>
              </div>
              <button type="submit" class="btn btn-primary btn-block">Send Message</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer>
  <?php include 'footer.php'?>
</footer>
  <!-- JS Scripts -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>