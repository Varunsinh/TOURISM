<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "userinfo");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Get city ID from URL
$city_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch city name
$city_name = "Unknown City";
if ($city_id) {
    $stmt = $conn->prepare("SELECT name FROM cities WHERE id = ?");
    $stmt->bind_param("i", $city_id);
    $stmt->execute();
    $stmt->bind_result($city_name_from_db);
    if ($stmt->fetch()) {
        $city_name = $city_name_from_db;
    }
    $stmt->close();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $city_id_post = $_POST['city_id'];
    $full_name = $_POST['full_name'];
    $state = $_POST['state'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $description = $_POST['description'];
    $travel_date = $_POST['travel_date'];
    $duration = $_POST['duration'];
    $persons = $_POST['persons'];

    $stmt = $conn->prepare("INSERT INTO city_bookings 
        (trip_id, full_name, state, email, contact, description, travel_date, duration, persons) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssssi", $city_id_post, $full_name, $state, $email, $contact, $description, $travel_date, $duration, $persons);

    if ($stmt->execute()) {
        echo "<script>alert('City booking successful!'); window.location='city_booking.php?id=" . htmlspecialchars($city_id_post) . "';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>City Booking</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    .form-section {
        max-width: 800px;
        margin: 40px auto;
        padding: 20px;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    }
    h2 { text-align: center; margin-bottom: 20px; color: #e63946; }
</style>
</head>
<body class="bg-light">

<div class="container">
    <div class="form-section">
        <h2>Book Your City Trip</h2>
        <form action="city_booking.php?id=<?php echo htmlspecialchars($city_id); ?>" method="POST">

            <input type="hidden" name="city_id" value="<?php echo htmlspecialchars($city_id); ?>">

            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label">Full Name*</label>
                    <input type="text" name="full_name" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">State*</label>
                    <select name="state" class="form-select" required>
                        <option value="">Select State</option>
                        <?php
                        $states = [
                            "AP"=>"Andhra Pradesh","AR"=>"Arunachal Pradesh","AS"=>"Assam","BR"=>"Bihar",
                            "CT"=>"Chhattisgarh","GA"=>"Gujarat","GO"=>"Goa","HR"=>"Haryana","HP"=>"Himachal Pradesh",
                            "JK"=>"Jammu and Kashmir","JH"=>"Jharkhand","KA"=>"Karnataka","KL"=>"Kerala",
                            "MP"=>"Madhya Pradesh","MH"=>"Maharashtra","MN"=>"Manipur","ML"=>"Meghalaya",
                            "MZ"=>"Mizoram","NL"=>"Nagaland","OR"=>"Odisha","PB"=>"Punjab","RJ"=>"Rajasthan",
                            "SK"=>"Sikkim","TN"=>"Tamil Nadu","TG"=>"Telangana","TR"=>"Tripura",
                            "UT"=>"Uttarakhand","UP"=>"Uttar Pradesh","WB"=>"West Bengal",
                            "AN"=>"Andaman and Nicobar Islands","CH"=>"Chandigarh","DN"=>"Dadra and Nagar Haveli",
                            "DD"=>"Daman and Diu","DL"=>"Delhi","LD"=>"Lakshadweep","PY"=>"Puducherry"
                        ];
                        foreach($states as $code=>$name){
                            echo "<option value='$code'>$name</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label">Email ID*</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Contact No*</label>
                    <input type="text" name="contact" class="form-control" required>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">City Description*</label>
                <input type="text" name="description" class="form-control" value="<?php echo htmlspecialchars($city_name); ?>" readonly>
            </div>

            <div class="row mb-3">
                <div class="col-md-4">
                    <label class="form-label">Travel Date*</label>
                    <input type="date" name="travel_date" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Duration of Stay*</label>
                    <input type="text" name="duration" class="form-control" placeholder="e.g. 3 Days" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">No of Persons*</label>
                    <input type="number" name="persons" class="form-control" min="1" required>
                </div>
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-success btn-lg">Book Now</button>
            </div>

        </form>
    </div>
</div>

</body>
</html>
