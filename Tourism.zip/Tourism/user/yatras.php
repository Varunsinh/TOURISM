<?php
require "../config.php"; // Database Connection

// Fetch all Yatras from DB
$yatras = mysqli_query($conn, "SELECT * FROM yatras ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Spiritual Yatras - IndiYatri</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .trip-card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: 0.3s ease;
    }

    .trip-card:hover {
      transform: scale(1.05);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
    }

    .trip-card img {
      height: 220px;
      object-fit: cover;
      border-radius: 10px 10px 0 0;
    }

    .card-body h5 {
      font-weight: bold;
    }

    .yatra-section {
      margin-top: 60px;
    }
  </style>
</head>

<body>

  <!-- Navbar -->
  <?php include 'header.php'; ?>

  <!-- Spiritual Yatras Section -->
  <section class="yatra-section py-5 px-3 px-md-5">
    <div class="py-3 text-center">
      <h2>Spiritual Yatras</h2>
      <p class="text-muted mb-4">Reconnect with India's spiritual soul through our guided Yatras.</p>
      <input id="yatraSearch" class="form-control mb-5 mx-auto d-block w-50" type="text"
        placeholder="Search for a Yatra..." />
    </div>

    <div class="container">
      <div id="yatraCards" class="row g-4">

        <!-- Dynamic Yatra Cards -->
        <?php while ($yatra = mysqli_fetch_assoc($yatras)) : ?>
          <div class="col-md-4 yatra-item">
            <div class="card trip-card">
              <img src="../uploads/yatras/<?php echo $yatra['image']; ?>" class="card-img-top"
                alt="<?php echo $yatra['name']; ?>"
                onerror="this.src='https://via.placeholder.com/400x220?text=Image+Not+Found'">
              <div class="card-body">
                <h5 class="card-title"><?php echo $yatra['name']; ?></h5>
                <p class="card-text"><?php echo $yatra['description']; ?></p>
                <a href="yatra_booking.php?id=<?php echo $yatra['id']; ?>" class="btn btn-success btn-sm">Book Now</a>
              </div>
            </div>
          </div>
        <?php endwhile; ?>

      </div>
    </div>
  </section>

  <!-- Footer -->
  <?php include 'footer.php'; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Live Search Filter -->
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const searchInput = document.getElementById("yatraSearch");
      const items = document.querySelectorAll(".yatra-item");
      const row = document.getElementById("yatraCards");

      searchInput.addEventListener("input", function() {
        const q = this.value.toLowerCase().trim();
        let shown = 0;

        items.forEach(card => {
          const title = card.querySelector(".card-title").textContent.toLowerCase();
          const text = card.querySelector(".card-text").textContent.toLowerCase();
          const match = title.includes(q) || text.includes(q);

          card.style.display = match ? "block" : "none";
          if (match) shown++;
        });

        shown === 1 ? row.classList.add("justify-content-center") :
          row.classList.remove("justify-content-center");
      });
    });
  </script>

</body>

</html>
