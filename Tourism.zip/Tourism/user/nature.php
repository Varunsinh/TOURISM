<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Nature - IndiYatri</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Josefin Sans', sans-serif;
    }

    .nature-card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .nature-card:hover {
      transform: scale(1.05);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
    }

    .nature-card img {
      height: 220px;
      object-fit: cover;
    }

    .card-body h5 {
      font-weight: bold;
    }

    .search-btn {
      background: linear-gradient(135deg, #1e90ff, #00bfff);
      color: #fff;
      border: none;
      padding: 8px 20px;
      border-radius: 30px;
      font-weight: 500;
      transition: all 0.3s ease;
    }

    .search-btn:hover {
      background: linear-gradient(135deg, #005cbf, #0096c7);
      transform: scale(1.05);
      box-shadow: 0 8px 15px rgba(0, 123, 255, 0.2);
    }

    .row.g-4>[class*="col-"] {
      margin-bottom: 30px;
    }

    .crossed-flag {
      font-weight: bold;
      font-size: 28px;
      background: linear-gradient(45deg, #ff9933 0%, #ffffff 50%, #138808 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: inline-block;
    }
  </style>
</head>

<body>
  <!-- Navbar -->
<header>
  <?php include 'header.php'?>
   </header>
  <!-- Nature Section -->
  <section class="my-5 py-5 px-3 px-md-5">
    <div class="py-3 text-center">
      <h2>Explore Indian Nature</h2>
      <p class="text-muted mb-4">Discover mountains, beaches, forests, and wildlife across India.</p>
      <input id="natureSearch" class="form-control mb-5 mx-auto d-block w-50" type="text" placeholder="Search nature..." />
    </div>

    <div class="container">
      <div id="natureCards" class="row g-4">
        <!-- Row 1 -->
        <div class="col-md-4">
          <div class="card nature-card" onclick="window.open('https://www.google.com/search?q=Himalayas', '_blank')" style="cursor: pointer;">
            <img src="image/himalayas.jpg" class="card-img-top" alt="Himalayas">
            <div class="card-body">
              <h5 class="card-title">Himalayas</h5>
              <p class="card-text">The majestic Himalayan mountain range, home to breathtaking peaks and valleys.</p>
              <p><a href="https://www.google.com/maps?q=Himalayas" target="_blank" class="text-primary">📍North India</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card nature-card" onclick="window.open('https://www.google.com/search?q=Kerala+Backwaters', '_blank')" style="cursor: pointer;">
            <img src="image/backwaters.jpg" class="card-img-top" alt="Kerala Backwaters">
            <div class="card-body">
              <h5 class="card-title">Kerala Backwaters</h5>
              <p class="card-text">A network of serene canals, rivers, and lakes surrounded by palm trees.</p>
              <p><a href="https://www.google.com/maps?q=Kerala+Backwaters" target="_blank" class="text-primary">📍Kerala</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card nature-card" onclick="window.open('https://www.google.com/search?q=Ranthambore+National+Park', '_blank')" style="cursor: pointer;">
            <img src="image/ranthambore.jpg" class="card-img-top" alt="Ranthambore National Park">
            <div class="card-body">
              <h5 class="card-title">Ranthambore National Park</h5>
              <p class="card-text">Famous wildlife sanctuary known for Bengal tigers and diverse species.</p>
              <p><a href="https://www.google.com/maps?q=Ranthambore" target="_blank" class="text-primary">📍Rajasthan</a></p>
            </div>
          </div>
        </div>

        <!-- Row 2 -->
        <div class="col-md-4">
          <div class="card nature-card" onclick="window.open('https://www.google.com/search?q=Goa+Beaches', '_blank')" style="cursor: pointer;">
            <img src="image/goa.jpg" class="card-img-top" alt="Goa Beaches">
            <div class="card-body">
              <h5 class="card-title">Goa Beaches</h5>
              <p class="card-text">Golden sands, blue waters, and a perfect mix of relaxation and adventure.</p>
              <p><a href="https://www.google.com/maps?q=Goa" target="_blank" class="text-primary">📍Goa</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card nature-card" onclick="window.open('https://www.google.com/search?q=Sundarbans', '_blank')" style="cursor: pointer;">
            <img src="image/sundarbans.jpg" class="card-img-top" alt="Sundarbans Mangroves">
            <div class="card-body">
              <h5 class="card-title">Sundarbans Mangroves</h5>
              <p class="card-text">The largest mangrove forest, home to the Royal Bengal tiger.</p>
              <p><a href="https://www.google.com/maps?q=Sundarbans" target="_blank" class="text-primary">📍West Bengal</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card nature-card" onclick="window.open('https://www.google.com/search?q=Valley+of+Flowers', '_blank')" style="cursor: pointer;">
            <img src="image/valley.jpg" class="card-img-top" alt="Valley of Flowers">
            <div class="card-body">
              <h5 class="card-title">Valley of Flowers</h5>
              <p class="card-text">A UNESCO World Heritage site covered with vibrant alpine flowers.</p>
              <p><a href="https://www.google.com/maps?q=Valley+of+Flowers" target="_blank" class="text-primary">📍Uttarakhand</a></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer>
  <?php include 'footer.php'?>
</footer>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Live Search -->
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const searchInput = document.getElementById("natureSearch");
      const cardContainer = document.getElementById("natureCards");
      const cards = document.querySelectorAll(".nature-card");

      searchInput.addEventListener("input", function() {
        const query = this.value.toLowerCase().trim();
        let matchCount = 0;

        cards.forEach(card => {
          const title = card.querySelector(".card-title").textContent.toLowerCase();
          const text = card.querySelector(".card-text").textContent.toLowerCase();
          const match = title.includes(query) || text.includes(query);

          card.parentElement.style.display = match || query === "" ? "block" : "none";
          if (match) matchCount++;
        });

        cardContainer.classList.remove("justify-content-center", "row");

        if (matchCount === 1) {
          cardContainer.classList.add("d-flex", "justify-content-center", "flex-wrap");
        } else {
          cardContainer.className = "row g-4";
        }
      });
    });
  </script>

</body>
</html>
