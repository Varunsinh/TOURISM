<?php
if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $filePath = "users.txt";

    // ✅ Check if file exists
    if (file_exists($filePath)) {
        $users = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        foreach ($users as $user) {
            list($savedUser, $savedPass) = explode(",", $user);

            if (strcasecmp($savedUser, $username) == 0) { 
                // case-insensitive match
                echo "exists"; 
                exit();
            }
        }
    }

    // ✅ If not exists, save new user
    $file = fopen($filePath, "a");
    fwrite($file, $username . "," . $password . "\n");
    fclose($file);

    echo "success";
}
?>
