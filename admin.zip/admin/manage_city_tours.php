<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tourism Admin - Manage City Tours</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="app">
        <?php include_once 'header.php'; ?>

        <div class="main">
            <header class="appbar">
                <h2>Manage City Tours</h2>
                <button class="btn primary" onclick="showAddForm()">+ Add City Tour</button>
            </header>

            <main class="content">
                <div class="card" id="addForm" style="display:none;">
                    <h3>Add New City Tour</h3>
                    <div class="form-inline">
                        <input type="text" id="tourName" placeholder="City Tour Name" required>
                        <input type="text" id="tourCity" placeholder="City" required>
                        <textarea id="tourDesc" placeholder="Description"></textarea>
                        <input type="file" id="tourImage" accept="image/*">
                        <button class="btn primary" onclick="addTour()">Save</button>
                    </div>
                </div>

                <div class="card">
                    <h3 style="margin:0 0 10px">City Tours List</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Name</th>
                                <th>City</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="cityToursTableBody"></tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <script>
        let cityTours = [{
                id: 'C-5001',
                name: 'Ahmedabad Heritage Walk',
                city: 'Ahmedabad',
                desc: 'Explore the heritage pols and stepwells of Ahmedabad',
                image: 'https://picsum.photos/100/60?11'
            },
            {
                id: 'C-5002',
                name: 'Jaipur City Tour',
                city: 'Jaipur',
                desc: 'Visit Amber Fort, City Palace, and Hawa Mahal',
                image: 'https://picsum.photos/100/60?12'
            }
        ];

        function renderTours() {
            const tbody = document.getElementById('cityToursTableBody');
            tbody.innerHTML = '';
            cityTours.forEach(t => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
          <td><img src=\"${t.image}\" class=\"city-img\"></td>
          <td>${t.name}</td>
          <td>${t.city}</td>
          <td>${t.desc}</td>
          <td class=\"actions-cell\">
            <button class=\"btn primary\" onclick=\"editTour('${t.id}')\">Edit</button>
            <button class=\"btn warn\" onclick=\"deleteTour('${t.id}')\">Delete</button>
          </td>`;
                tbody.appendChild(tr);
            });
        }

        function showAddForm() {
            document.getElementById('addForm').style.display = 'block';
        }

        function addTour() {
            const name = document.getElementById('tourName').value;
            const city = document.getElementById('tourCity').value;
            const desc = document.getElementById('tourDesc').value;
            const imgFile = document.getElementById('tourImage').files[0];
            let imgUrl = 'https://picsum.photos/100/60?random=' + Math.random();

            if (imgFile) {
                imgUrl = URL.createObjectURL(imgFile);
            }

            const id = 'C-' + (5000 + cityTours.length + 1);
            cityTours.push({
                id,
                name,
                city,
                desc,
                image: imgUrl
            });
            renderTours();
            alert('City Tour ' + id + ' added');
        }

        function editTour(id) {
            const t = cityTours.find(x => x.id === id);
            if (!t) return;
            const newName = prompt('Edit Name:', t.name);
            if (newName !== null) t.name = newName;
            const newCity = prompt('Edit City:', t.city);
            if (newCity !== null) t.city = newCity;
            const newDesc = prompt('Edit Description:', t.desc);
            if (newDesc !== null) t.desc = newDesc;
            renderTours();
        }

        function deleteTour(id) {
            if (confirm('Delete City Tour ' + id + '?')) {
                cityTours = cityTours.filter(x => x.id !== id);
                renderTours();
            }
        }

        renderTours();
    </script>
</body>

</html>