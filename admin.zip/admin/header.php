    <aside class="sidebar" id="sidebar">
      <div class="brand">
        <div class="logo">TM</div>
        <div class="brand-text">
          <h1>Tourism Manager</h1>
          <div class="muted">Admin panel</div>
        </div>
      </div>

      <nav class="nav">
        <a href="dashboard.php" class="active"><svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M3 13h8V3H3v10zM13 21h8V11h-8v10zM3 21h8v-6H3v6zM13 11h8V3h-8v8z" fill="currentColor" />
          </svg> Dashboard</a>
        <a href="manage_users.php"><svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M12 12c2.761 0 5-2.239 5-5s-2.239-5-5-5-5 2.239-5 5 2.239 5 5 5zm0 2c-4.418 0-8 1.79-8 4v2h16v-2c0-2.21-3.582-4-8-4z" fill="currentColor" />
          </svg> Manage Users</a>
        <a href="manage_bookings.php"><svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M7 4h10l3 6v9a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4h3z" fill="currentColor" />
          </svg> Manage Bookings</a>
        <a href="manage_yatras.php"><svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M21 10V7a2 2 0 0 0-2-2h-3l-2-2H10L8 5H5a2 2 0 0 0-2 2v3l-1 8h22l-1-8zM7 20a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm10 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" fill="currentColor" />
          </svg> Manage Yatras </a>
        <a href="manage_advantures.php"><svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M21 10V7a2 2 0 0 0-2-2h-3l-2-2H10L8 5H5a2 2 0 0 0-2 2v3l-1 8h22l-1-8zM7 20a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm10 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" fill="currentColor" />
          </svg> Manage Advantures </a>
        <a href="manage_city_tours.php"><svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M21 10V7a2 2 0 0 0-2-2h-3l-2-2H10L8 5H5a2 2 0 0 0-2 2v3l-1 8h22l-1-8zM7 20a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm10 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" fill="currentColor" />
          </svg> Manage City Tours</a>
        <!-- <a href="#"><svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M21 10V7a2 2 0 0 0-2-2h-3l-2-2H10L8 5H5a2 2 0 0 0-2 2v3l-1 8h22l-1-8zM7 20a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm10 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" fill="currentColor" />
          </svg> Trips </a> -->
        <a href="manage_contacts.php"><svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M21 8V7l-3 2-2-2-4 3-5-4-2 2v6h16V8z" fill="currentColor" />
          </svg> Manage Contacts</a>
      </nav>

      <div class="footer-small">© <span id="year"></span> IndiYatri </div>
    </aside>