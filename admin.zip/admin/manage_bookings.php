<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Tourism Admin - Manage Bookings</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="app">
    <?php include_once 'header.php'; ?>

    <div class="main">
      <header class="appbar">
        <h2>Manage Bookings</h2>
        <button class="btn primary" onclick="addBooking()">+ Add Booking</button>
      </header>

      <main class="content">
        <div class="card">
          <h3 style="margin:0 0 10px">Booking List</h3>
          <table>
            <thead>
              <tr>
                <th>Booking ID</th>
                <th>User</th>
                <th>Trip</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="bookingsTableBody"></tbody>
          </table>
        </div>
      </main>
    </div>
  </div>

  <script>
    const bookings = [{
        id: 'B-2001',
        user: 'Amit Shah',
        trip: 'Kedarnath Yatra',
        date: '2025-09-12',
        status: 'Confirmed'
      },
      {
        id: 'B-2002',
        user: 'Priya Patel',
        trip: 'Amarnath Yatra',
        date: '2025-09-15',
        status: 'Pending'
      },
      {
        id: 'B-2003',
        user: 'Rahul Mehta',
        trip: 'Varanasi Pilgrimage',
        date: '2025-09-20',
        status: 'Cancelled'
      }
    ];

    function renderBookings() {
      const tbody = document.getElementById('bookingsTableBody');
      tbody.innerHTML = '';
      bookings.forEach(b => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${b.id}</td>
          <td>${b.user}</td>
          <td>${b.trip}</td>
          <td>${b.date}</td>
          <td>${b.status}</td>
          <td class="actions-cell">
            <button class="btn primary" onclick="editBooking('${b.id}')">Edit</button>
            <button class="btn warn" onclick="deleteBooking('${b.id}')">Delete</button>
          </td>`;
        tbody.appendChild(tr);
      });
    }

    function addBooking() {
      const id = 'B-' + (2000 + bookings.length + 1);
      bookings.push({
        id,
        user: 'New User',
        trip: 'Sample Trip',
        date: '2025-09-30',
        status: 'Pending'
      });
      renderBookings();
      alert('Booking ' + id + ' added (sample)');
    }

    function editBooking(id) {
      const b = bookings.find(x => x.id === id);
      if (!b) return;
      const newStatus = prompt('Update booking status:', b.status);
      if (newStatus !== null) {
        b.status = newStatus;
        renderBookings();
      }
    }

    function deleteBooking(id) {
      if (confirm('Delete booking ' + id + '?')) {
        const idx = bookings.findIndex(x => x.id === id);
        if (idx > -1) {
          bookings.splice(idx, 1);
          renderBookings();
        }
      }
    }

    renderBookings();
  </script>
</body>

</html>