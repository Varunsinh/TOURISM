<?php
// Update these values for your environment
// $DB_HOST = 'localhost';
// $DB_USER = 'root';
// $DB_PASS = '';
// $DB_NAME = 'tourism_db';

// $con = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
// if (!$con) {
//     die('Database connection failed: ' . mysqli_connect_error());
// }
// mysqli_set_charset($con, 'utf8mb4');
?>
