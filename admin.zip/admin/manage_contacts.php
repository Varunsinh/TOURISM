<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tourism Admin - Manage Contact Forms</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="app">
        <?php include_once 'header.php'; ?>

        <div class="main">
            <header class="appbar">
                <h2>Manage Contact Forms</h2>
            </header>

            <main class="content">
                <div class="card">
                    <h3 style="margin:0 0 10px">User Messages</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Message</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="contactsTableBody"></tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <script>
        let contacts = [{
                id: 'M-7001',
                name: 'Ravi Patel',
                email: 'ravi@example.com',
                message: 'I want details about Kedarnath Yatra',
                status: 'Unread'
            },
            {
                id: 'M-7002',
                name: 'Anjali Sharma',
                email: 'anjali@example.com',
                message: 'How can I book a Manali Adventure package?',
                status: 'Read'
            }
        ];

        function renderContacts() {
            const tbody = document.getElementById('contactsTableBody');
            tbody.innerHTML = '';
            contacts.forEach(c => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
          <td>${c.name}</td>
          <td>${c.email}</td>
          <td>${c.message}</td>
          <td>${c.status}</td>
          <td class="actions-cell">
            <button class="btn secondary" onclick="markRead('${c.id}')">Mark Read</button>
            <button class="btn primary" onclick="replyMessage('${c.email}')">Reply</button>
            <button class="btn warn" onclick="deleteMessage('${c.id}')">Delete</button>
          </td>`;
                tbody.appendChild(tr);
            });
        }

        function markRead(id) {
            const msg = contacts.find(x => x.id === id);
            if (msg) {
                msg.status = 'Read';
                renderContacts();
            }
        }

        function replyMessage(email) {
            alert('Open your email client to reply to: ' + email);
        }

        function deleteMessage(id) {
            if (confirm('Delete this message?')) {
                contacts = contacts.filter(x => x.id !== id);
                renderContacts();
            }
        }

        renderContacts();
    </script>
</body>

</html>