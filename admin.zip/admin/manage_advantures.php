<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tourism Admin - Manage Adventures</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="app">
        <?php include_once 'header.php'; ?>

        <div class="main">
            <header class="appbar">
                <h2>Manage Adventures</h2>
                <button class="btn primary" onclick="showAddForm()">+ Add Adventure</button>
            </header>

            <main class="content">
                <div class="card" id="addForm" style="display:none;">
                    <h3>Add New Adventure</h3>
                    <div class="form-inline">
                        <input type="text" id="advName" placeholder="Adventure Name" required>
                        <input type="text" id="advLocation" placeholder="Location" required>
                        <textarea id="advDesc" placeholder="Description"></textarea>
                        <input type="file" id="advImage" accept="image/*">
                        <button class="btn primary" onclick="addAdventure()">Save</button>
                    </div>
                </div>

                <div class="card">
                    <h3 style="margin:0 0 10px">Adventure List</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Location</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="adventuresTableBody"></tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <script>
        let adventures = [{
                id: 'A-4001',
                name: 'River Rafting',
                location: 'Rishikesh',
                desc: 'Exciting rafting experience on the Ganga river',
                image: 'https://picsum.photos/100/60?3'
            },
            {
                id: 'A-4002',
                name: 'Paragliding',
                location: 'Manali',
                desc: 'Fly over the mountains with a thrilling paragliding session',
                image: 'https://picsum.photos/100/60?4'
            }
        ];

        function renderAdventures() {
            const tbody = document.getElementById('adventuresTableBody');
            tbody.innerHTML = '';
            adventures.forEach(a => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
          <td><img src=\"${a.image}\" class=\"adventure-img\"></td>
          <td>${a.name}</td>
          <td>${a.location}</td>
          <td>${a.desc}</td>
          <td class=\"actions-cell\">
            <button class=\"btn primary\" onclick=\"editAdventure('${a.id}')\">Edit</button>
            <button class=\"btn warn\" onclick=\"deleteAdventure('${a.id}')\">Delete</button>
          </td>`;
                tbody.appendChild(tr);
            });
        }

        function showAddForm() {
            document.getElementById('addForm').style.display = 'block';
        }

        function addAdventure() {
            const name = document.getElementById('advName').value;
            const loc = document.getElementById('advLocation').value;
            const desc = document.getElementById('advDesc').value;
            const imgFile = document.getElementById('advImage').files[0];
            let imgUrl = 'https://picsum.photos/100/60?random=' + Math.random();

            if (imgFile) {
                imgUrl = URL.createObjectURL(imgFile);
            }

            const id = 'A-' + (4000 + adventures.length + 1);
            adventures.push({
                id,
                name,
                location: loc,
                desc,
                image: imgUrl
            });
            renderAdventures();
            alert('Adventure ' + id + ' added');
        }

        function editAdventure(id) {
            const a = adventures.find(x => x.id === id);
            if (!a) return;
            const newName = prompt('Edit Name:', a.name);
            if (newName !== null) a.name = newName;
            const newLoc = prompt('Edit Location:', a.location);
            if (newLoc !== null) a.location = newLoc;
            const newDesc = prompt('Edit Description:', a.desc);
            if (newDesc !== null) a.desc = newDesc;
            renderAdventures();
        }

        function deleteAdventure(id) {
            if (confirm('Delete Adventure ' + id + '?')) {
                adventures = adventures.filter(x => x.id !== id);
                renderAdventures();
            }
        }

        renderAdventures();
    </script>
</body>

</html>