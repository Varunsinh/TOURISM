<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tourism Admin - Manage Yatras</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="app">
        <aside class="sidebar">
            <div class="brand">
                <div class="logo">TM</div>
                <h1>Tourism Manager</h1>
            </div>
            <nav class="nav">
                <a href="dashboard.php">Dashboard</a>
                <a href="manage_users.php">Users</a>
                <!-- <a href="manage_trips.php">Trips</a> -->
                <a href="manage_contacts.php">Contacts</a>
                <a href="manage_bookings.php">Bookings</a>
                <a href="manage_yatras.php" class="active">Yatras</a>
                <!-- <a href="reviews.html">Reviews</a> -->
             <!-- <a href="settings.html">Settings</a> -->
            </nav>
        </aside>

        <div class="main">
            <header class="appbar">
                <h2>Manage Yatras</h2>
                <button class="btn primary" onclick="showAddForm()">+ Add Yatra</button>
            </header>

            <main class="content">
                <div class="card" id="addForm" style="display:none;">
                    <h3>Add New Yatra</h3>
                    <div class="form-inline">
                        <input type="text" id="yatraName" placeholder="Yatra Name" required>
                        <input type="text" id="yatraLocation" placeholder="Location" required>
                        <textarea id="yatraDesc" placeholder="Description"></textarea>
                        <input type="file" id="yatraImage" accept="image/*">
                        <button class="btn primary" onclick="addYatra()">Save</button>
                    </div>
                </div>

                <div class="card">
                    <h3 style="margin:0 0 10px">Yatra List</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Location</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="yatrasTableBody"></tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <script>
        let yatras = [{
                id: 'Y-3001',
                name: 'Kedarnath Yatra',
                location: 'Uttarakhand',
                desc: 'A holy trek to Kedarnath temple',
                image: 'https://picsum.photos/100/60?1'
            },
            {
                id: 'Y-3002',
                name: 'Amarnath Yatra',
                location: 'Jammu & Kashmir',
                desc: 'Spiritual journey to the ice Shiva Linga',
                image: 'https://picsum.photos/100/60?2'
            }
        ];

        function renderYatras() {
            const tbody = document.getElementById('yatrasTableBody');
            tbody.innerHTML = '';
            yatras.forEach(y => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
          <td><img src=\"${y.image}\" class=\"yatra-img\"></td>
          <td>${y.name}</td>
          <td>${y.location}</td>
          <td>${y.desc}</td>
          <td class=\"actions-cell\">
            <button class=\"btn primary\" onclick=\"editYatra('${y.id}')\">Edit</button>
            <button class=\"btn warn\" onclick=\"deleteYatra('${y.id}')\">Delete</button>
          </td>`;
                tbody.appendChild(tr);
            });
        }

        function showAddForm() {
            document.getElementById('addForm').style.display = 'block';
        }

        function addYatra() {
            const name = document.getElementById('yatraName').value;
            const loc = document.getElementById('yatraLocation').value;
            const desc = document.getElementById('yatraDesc').value;
            const imgFile = document.getElementById('yatraImage').files[0];
            let imgUrl = 'https://picsum.photos/100/60?random=' + Math.random();

            if (imgFile) {
                imgUrl = URL.createObjectURL(imgFile);
            }

            const id = 'Y-' + (3000 + yatras.length + 1);
            yatras.push({
                id,
                name,
                location: loc,
                desc,
                image: imgUrl
            });
            renderYatras();
            alert('Yatra ' + id + ' added');
        }

        function editYatra(id) {
            const y = yatras.find(x => x.id === id);
            if (!y) return;
            const newName = prompt('Edit Name:', y.name);
            if (newName !== null) y.name = newName;
            const newLoc = prompt('Edit Location:', y.location);
            if (newLoc !== null) y.location = newLoc;
            const newDesc = prompt('Edit Description:', y.desc);
            if (newDesc !== null) y.desc = newDesc;
            renderYatras();
        }

        function deleteYatra(id) {
            if (confirm('Delete Yatra ' + id + '?')) {
                yatras = yatras.filter(x => x.id !== id);
                renderYatras();
            }
        }

        renderYatras();
    </script>
</body>

</html>