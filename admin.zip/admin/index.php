<?php
session_start();
// require_once __DIR__.'/config/db.php';

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username'] ?? '');
  $password = $_POST['password'] ?? '';

  if ($username === '' || $password === '') {
    $err = 'Enter username and password';
  } else {
    $stmt = mysqli_prepare($con, "SELECT * FROM admins WHERE username=? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($res)) {
      if (password_verify($password, $row['password_hash'])) {
        $_SESSION['admin_id'] = $row['id'];
        $_SESSION['admin_name'] = $row['name'];
        header('Location: /admin/dashboard.php');
        exit;
      }
    }
    $err = 'Invalid credentials';
    mysqli_stmt_close($stmt);
  }
}
?>
<!doctype html>
<html>

<head>
  <meta charset="utf-8">
  <title>Admin Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #6a11cb, #2575fc);
    }

    .card {
      width: 100%;
      max-width: 420px;
      border: none;
      border-radius: 14px;
      box-shadow: 0 15px 35px rgba(0, 0, 0, .15);
    }

    .btn-primary {
      background: #7c3aed;
      border: none;
    }

    .btn-primary:hover {
      background: #6d28d9;
    }
  </style>
</head>

<body>
  <div class="card p-4 bg-white">
    <h3 class="text-center mb-3">Admin Login</h3>
    <?php if ($err): ?><div class="alert alert-danger py-2"><?= htmlspecialchars($err) ?></div><?php endif; ?>
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" class="form-control" name="username" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" class="form-control" name="password" required>
      </div>
      <button class="btn btn-primary w-100">Login</button>
    </form>
  </div>
</body>

</html>